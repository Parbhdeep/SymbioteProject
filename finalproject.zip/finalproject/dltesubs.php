<?php
include_once("session.php");
ob_start();
include_once("db.php");

$delquery="delete from subject_allocation where sa_id='$_GET[sa_id]'";
$exe1= mysql_query($delquery);

header("location:sub_allot.php?msg=deleted$sa_id='$_GET[sa_id]'");	//for redirecting page to new page after login success

?>