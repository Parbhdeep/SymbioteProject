<?php
include_once("session.php");
include_once("db.php");

$delquery="delete from class where class_id='$_GET[class_id]'";
$exe1= mysql_query($delquery);

header("location:clsses.php?msg=deleted$class_id='$_GET[class_id]'");	//for redirecting page to new page after login success

?>