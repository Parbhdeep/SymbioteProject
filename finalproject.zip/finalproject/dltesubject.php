<?php
include_once("session.php");
include_once("db.php");

$delquery="delete from subject where subject_id='$_GET[subject_id]'";
$exe1= mysql_query($delquery);

header("location:subject.php?msg=deleted$subject_id='$_GET[subject_id]'");	//for redirecting page to new page after login success

?>