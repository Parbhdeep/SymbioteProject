<?php
include_once("session.php");
include_once("teacherheader.php");
?>
<?php
ob_start();
include_once("db.php");

include_once("getclass.php");

//include_once("funcSession.php");
include_once("getsubjects.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />


<script>

function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="getsection.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}

function gett()
{
	var xmlhttp;
	
	if(window.XMLHttpRequest)
	{//code for IE7+,firefox,chorme,opera,safari
	 xmlhttp = new XMLHttpRequest();
	}
	else
	{//code for IE6,IE5
	xmlhttp = new ActiveXobject("Microsoft.XMLHTTP");
	}
	
var url = "insertattend.php";
	

var classid = document.getElementById('classs').value;	
var sectionid = document.getElementById('ssid').value;	
//url = url +"?testid="+testid;

url = url +"?classid="+classid+"&sectionid="+sectionid;
//alert(url);
xmlhttp.open("GET", url, true);
xmlhttp.send();

	xmlhttp.onreadystatechange=function()
	{
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
			  {
			document.getElementById("testt").innerHTML=xmlhttp.responseText;
				   
			  }
		 }
}

</script>
<script>
function insert(){
var xmlhttp;

	if(window.XMLHttpRequest)
	{//code for IE7+,firefox,chorme,opera,safari
	 xmlhttp = new XMLHttpRequest();
	}
	else
	{//code for IE6,IE
	xmlhttp = new ActiveXobject("Microsoft.XMLHTTP");
	}
	
var classid=document.getElementById("classs").value;
//alert(classid);
var sectionid=document.getElementById("ssid").value;
//alert(sectionid);
var subid=document.getElementById("sub").value;
//alert(subid);
//var status=document.getElementById("checkk").value;
//var month=document.getElementById("month").value;
//var month=document.getElementById("month").value;
var values = new Array();
var present=document.querySelectorAll("input[name='present[]']");
var length=present.length;
for(var i=0;i<length;i++)
{
if(present[i].checked)
{
values[i] = "p";
}
else
{
values[i] = "a";
}
}

var url="insertattendences.php";
url=url+"?classid="+classid+"&sectionid="+sectionid+"&present="+values+"&subid="+subid;
//alert(url);
xmlhttp.open("GET", url, true);
xmlhttp.send();

return false;		
}
</script>
<script>
function choseall() {
    var x = document.querySelectorAll("input[name='present[]']");
    for (var i = 0; i < x.length; i++) {
        if (x[i].checked) {
            x[i].checked = false;
        } else {
            x[i].checked = true;
        }
    }
}
function chose() {
    var x = document.querySelectorAll("input[name='present[]']");
    for (var i = 0; i < x.length; i++) {
        if (x[i].checked) {
            x[i].value = 0;
        } else {
            x[i].value =1;
        }
    }
}
function subject()
{
var x=document.attendence.sub.value;
if(x==""||x==null)
{
alert("subject name must be filled out");
  document.attendence.sub.focus();
 return false;
}
}
function sub()
{
var x=document.attendence.cid.value;
if(x==""||x==null)
{
alert("class name must be filled out");
  document.attendence.sub.focus();
 return false;
}
var x=document.attendence.sid.value;
if(x==""||x==null)
{
alert("section name must be filled out");
  document.attendence.sub.focus();
 return false;
}
}
</script>
</head>

<body bgcolor="#c0cec2">

<div id="form">
    <center>
	<h2>Insert Attendence</h2>
	<form name="attendance" method="post" >
<table align="right">
		<tr>
	<td><?php //include_once("admin_navigation.php"); ?></td>
	
	</tr>
</table>
<br><br><br>


ClassName:
<select name="cid" id="classs" onChange="getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php sctn(); ?>
</select>
<br><br>



sectionName:
<select name="sid" id="ssid" onChange="gett();">
<OPTION VALUE="">---select section---</OPTION>
<?php  ?>
</select>


<BR/><BR/><BR>


 <div id="testt"></div>
</form>
</DIV>
</body>
</html>
<?php
include_once("footer1.php");
?>
