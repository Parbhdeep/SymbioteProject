<link rel="stylesheet" href="style.css">
<div id="footer">

</div>
<div id="followus">
<h3 STYLE="COLOR:RED">FOLLOW US</H3><BR/>
<a href="http://twitter.com"><img src="image/twitter.jpg" height="40" width="40"/></a><a href="http://facebook.com"><img src="image/fb.jpg" height="40" width="40"/></a>
<DIV id="contactus"><h3 STYLE="COLOR:RED">CONTACT US</H3><br/>EUREKA ELECTROSOFT SOLUTIONS Pvt.Ltd<br/>Plot No.: E-55, F1st floor<br/> Phase-8 Industrial Area<br/> Near C-DAC Mohali (Punjab)<br/>Ph.: 0172-4638606, 5091855<br/> M: 9815216606.</div>
<div id="Enquiry"><h3 STYLE="COLOR:RED">ENQUIRY</H3>
<form name="contact" method="post" onsubmit="return validate();">  
 Name*<br/><input name="name" type="text"   onfocus="if(this.value=='Your Name')this.value=''" onblur="if(this.value=='')this.value='Your Name'"/><BR/><BR/>
   Email_Id*<br/><input name="email" type="text"   onfocus="if(this.value=='Your E-mail Address')this.value=''" onblur="if(this.value=='')this.value='Your E-mail Address'"/><BR/><BR/>
    <textarea name="txt_msg"  rows="" cols="" onfocus="if(this.value=='Put your message here')this.value=''" onblur="if(this.value=='')this.value='Put your message here'">Put your message here</textarea><br/><br/>
   <INPUT TYPE="SUBMIT" NAME="submit" value="submit"/></form>
 </div>
</div>
<div id="footer1"> Copyright Information EESPL. All Rights Reserved.</div></body>
<html>