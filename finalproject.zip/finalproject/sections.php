<?php
include_once("session.php");
include_once("db.php");
include_once("getclass.php");
include_once("schoolheader.php");
?>
<html>
<body bgcolor="#c0cec2">
<link href="style.css" rel="stylesheet" type="text/css" />
<title>A4 Project</title>
<script>
function validateFormm()
{

var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class name must be filled out");
  document.student.cid.focus();
 return false;
  }

var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section name must be filled out");
  document.student.sid.focus();
 return false;
  }  }
</script>
<title>A4 project</title>

<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>
<center>
		<h2>Enter Section</h2>
		<div id="form3">
		<form name="student" method="post" onsubmit="return validateFormm();">
		<table>
		<tr>
		<td>
<select name="cname" id=cid>
<OPTION VALUE="">---select class---</OPTION>
<?php sctn(); ?>
</select>
</td>
<td>
			section name:<input type="text" name="section" id="sid" placeholder="section name"></br></td>
			</tr>
			<tr width="60%"><td><input type="submit" name="submit" value="submit">
			<input type="reset" name="clear" value="clear"></td></tr>
			</table>
			</form>
			</div>
			</center>
<?php
include_once("db.php");
if(isset($_POST['submit']))
{
$section=$_POST['section'];
$class=$_POST['cname'];
$select="select * from section where section_name='$section' AND class_id='$class' ";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Section already exist")';
print'</script>';

}
else
{
$sett="insert into section set section_name='$_POST[section]',class_id='$_POST[cname]'";
mysql_query($sett);

}
}
?>

<?php	
ob_start();
include_once("db.php");
//include_once("session.php");
//include_once("admin_navigation.php");


error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM section";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);

?>
<center>
<div id="table">
<table border="" width="70%">
<tr>
	<th>Class name</th>
	<th>Section name</th>
	
	
</tr>
<?php
//number of results per page
$display=2;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM section $limitQ";
$result11=mysql_query($query11);


while($fetch=mysql_fetch_object($result11))
{
$abc="select * from class where class_id='$fetch->class_id'";
$def=mysql_query($abc);
$ab=mysql_fetch_array($def);

?>
<tr><td><?php echo $ab['class_name'];?></td>
	<td><?php print "$fetch->section_name"?></td>
	
	<td><a href= "editsections.php?section_id=<?php print "$fetch->section_id;"?>&class_id=<?php echo "$fetch->class_id"?>">Edit  </a></td>
    <td><a href= "dltesections.php?section_id=<?php print "$fetch->section_id;"?>&class_id=<?php echo "$fetch->class_id"?>">Delete  </a></td>
	
</tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=sections.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=sections.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}else{
$nextPage=$currentPage+1;
print "<a href=sections.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=sections.php?page=$lastPage>Last</a>";
}
?>

</center>
</div>
</body>
</html>
<?php
include_once("footer1.php");
?>
