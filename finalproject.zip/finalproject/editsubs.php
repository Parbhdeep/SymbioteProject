<?php
include_once("session.php");
ob_start();
include_once("schoolheader.php");
include_once("db.php");
include_once("getclass.php");
include_once("getsubjects.php");
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
$select121="Select * from subject_allocation where sa_id='$_GET[sa_id]'"; 
$exe121=mysql_query($select121);
$fetch11=mysql_fetch_array($exe121); 
$abcde=$_GET[class_id];
$subj=$_GET[subject_id];
if(isset($_POST['submit']))

{
$select="select * from subject_allocation where class_id='$_POST[cid]' && subject_id='$_POST[subid]' && section_id='$_POST[sid]'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert(" already exist")';
print'</script>';
}
else
{
$updatequery="update subject_allocation set class_id='$_POST[cid]',section_id='$_POST[sid]',subject_id='$_POST[subid]'
where sa_id='$_GET[sa_id]'";
$exe1= mysql_query($updatequery);

header("location:sub_allot.php?msg=updated$sa_id='$_GET[sa_id]'");	//for redirecting page to new page after login success
}
}
?>
<?php
function se($cll)
{
$sell="select * from class";
$exee=mysql_query($sell);
while($fetchh=mysql_fetch_array($exee))
{
?>
<option value='<?php echo $fetchh['class_id'];?>'<?php if($fetchh['class_id']==$cll){ echo "selected='selected'";}?> ><?php echo $fetchh['class_name'];?></option>

<?php

}
}
?>
<?php
function sb($cll)
{
$sell="select * from subject";
$exee=mysql_query($sell);
while($fetchh=mysql_fetch_array($exee))
{
?>
<option value='<?php echo $fetchh['subject_id'];?>'<?php if($fetchh['subject_id']==$cll){ echo "selected='selected'";}?> ><?php echo $fetchh['subject_name'];?></option>

<?php

}
}
?>
<?php
function sect($cla)
{
$selll="select * from section where class_id='$cla'";
$exeee=mysql_query($selll);
while($fetchhh=mysql_fetch_array($exeee))
{?>
<option value='<?php echo $fetchhh['section_id'];?>'<?php if($fetchhh['class_id']==$cla){ echo "selected='selected'";}?> ><?php echo $fetchhh['section_name'];?></option>

<?php

}
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />

<script>
function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="getsection.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}
</script>
<script>

function validateFormm()



{

	var classid=document.forms["sub"]["cid"].value;
	//var secid=document.forms["sub"]["sid"].value;
	
	
if (classid==null || classid=="")
  {
  alert("class id   must be filled out");
  document.sub.cid.focus();
 return false;
  }

/*if (secid==null || secid=="")
  {
  alert("section  must be filled out");
   document.sub.sname.focus();
 return false;
  }*/

		
	}



</script>
</head>

<body bgcolor="#c0cec2">
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>

 <center>
 <h2>Edit Subject</h2>
 <form name="sub"action="" method="post" enctype="multipart/form-data" onSubmit="return validateFormm();">
 <table>
</table>
<table >
<tr>
<td>ClassName:</td>
<td><select name="cid" id="classs" onChange="getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php se($abcde); ?>
</select></td>
</tr>
<tr>
<td>sectionName:</td>
<td><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php sect($abcde); ?>
</select></td>
</tr>
<tr>
<td>SubjectName:</td>
<td><select name="subid" id="siddd">
<OPTION VALUE="">---select subject---</OPTION>
<?php sb($subj);?>
</select></td>
</tr>
<tr>
<td>
<input type="submit" name="submit" value="submit"/>
</td>

<td>
<input type="reset" name="submitt" value="Clear">
</td>
</tr>
</table>
</center>
</form>

<?php
include_once("footer2.php");
?>