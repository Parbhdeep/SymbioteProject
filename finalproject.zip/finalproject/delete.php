<?php
include_once("session.php");
include_once("db.php");
$del="delete from student_id where stu_id='$_GET[stu_id]'";
mysql_query($del);
$delp="delete from parent where parent_id='$_GET[parent_id]'";
mysql_query($delp);

$select1="select * from section where class_id='$_GET[class_id]' and section_id='$_GET[section_id]'";
$exe1=mysql_query($select1);
$fetchs=mysql_fetch_array($exe1);
$strength=$fetchs['strength'];
$strength=$strength-1;

$update = "update section set strength='$strength' where class_id='$_GET[class_id]' and section_id='$_GET[section_id]'";
$uexe=mysql_query($update);
header("location:section.php");
?>
