<?php
include_once("db.php");
//error_reporting(E_ALL^(E_NOTICE));
$classid=$_GET['classid'];
$sectionid=$_GET['sectionid'];
$testid=$_GET['testid'];
$select133="Select * from student_id where	class_id='$classid' and section_id='$sectionid'"; 

 $exe111=mysql_query($select133);
 $rows=mysql_num_rows($exe111);
 ?> 
<head><link href="style2.css" rel="stylesheet" type="text/css" /></head>
 <table border>
<tr><td>studentId</td><td>NAME</td><td>score</td></tr>
   <?php
 
while( $result111 = mysql_fetch_array($exe111))
     {
     ?>
	
	<tr><td><?php echo $result111['stu_id'];?></td> <td><?php echo $result111['stu_name'];?></td><td><INPUT TYPE="text" name="score[]" id="score"/></TD></tr>
	
<?php } ?>

<head><link href="style2.css" rel="stylesheet" type="text/css" /></head>
 
<hr/>search result
</hr>
<hr/> 

</hr>
 <tr><td><input type="BUTTON" name="add" value="add" onclick="return insert();"/></td></tr>
</table>
</form>
</body>
</html>


