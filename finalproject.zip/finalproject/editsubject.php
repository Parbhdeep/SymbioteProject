<?php
include_once("session.php");
ob_start();
include_once("db.php");
include_once("schoolheader.php");
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
$select121="Select * from subject where subject_id='$_GET[subject_id]'"; 
$exe121=mysql_query($select121);
$fetch11=mysql_fetch_array($exe121); 

if(isset($_POST['submit']))
{
$subject=$_POST['sname'];
$sid=$_POST['sid'];
$select="select * from subject where subject_name='$subject' AND subject_id='$sid' ";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Subject already exist")';
print'</script>';

}
else
{
$updatequery="update subject set subject_name='$_POST[sname]',subject_id='$_POST[sid]'
where subject_id='$_GET[subject_id]'";
$exe1= mysql_query($updatequery);

header("location:subject.php?msg=updated$subject_id='$_GET[subject_id]'");	//for redirecting page to new page after login success

}
}
?>
<script>
function validateFormm()
{

var x=document.forms["subject"]["sname"].value;
if (x==null || x=="")
  {
  alert("subject name must be filled out");
  document.student.sname.focus();
 return false;
  }
var x=document.forms["subject"]["sid"].value;
if (x==null || x=="")
  {
  alert("subject id must be filled out");
  document.student.sid.focus();
 return false;
  }
}

</script>
<html>
<body bgcolor="#c0cec2">
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>
<title>A4 Project</title>
		<center>
		<h2>Edit Subject</h2>
		<form name="subject" method="post" onsubmit="return validateFormm();">
		<table border="0" cellpadding="10" cellspacing="0" width="300" align="center">
		<tr>
			<td width="40%">subject name:</td>
			<td width="60%"><input type="text" name="sname" id="sname" value="<?php echo $fetch11['subject_name'];?>"></br></td>
			</tr>
			<tr>
		    <td width="40%">subject id:</td>
			<td width="60%"><input type="text" name="sid" id="sid" value="<?php echo $fetch11['subject_id'];?> "></br></td>
			</tr>
			<tr>
			<td width="40%"><input type="submit" name="submit" value="submit"></td>
			<td width="40%"><input type="reset" name="clear" value="clear"></td>
			</tr>
			</table>
			</form>
			</center>

<?php
include_once("footer2.php");
?>