<?php
include_once("session.php");
include_once("db.php");
$del="delete from admin where admin_id='$_GET[admin_id]'";
mysql_query($del);
header("location:admin.php?msg=deleted$admin_id='$_GET[admin_id]'");
?>
