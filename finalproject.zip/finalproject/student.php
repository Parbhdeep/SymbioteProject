<?php
ob_start();
include_once("session.php");
include_once("db.php");
include_once("func.php");
//("session.php");
if(isset($_POST['submit']))
{

$uname=$_POST['eid'];
$select1="select * from section where class_id='$_POST[cid]' and section_id='$_POST[sid]'";
$exe1=mysql_query($select1);
$fetchs=mysql_fetch_array($exe1);
$strength=$fetchs['strength'];
$strength=$strength+1;
//$date =date("Y-m-d h:i:s");
$filename=$_FILES['file']['tmp_name'];
$select="select * from student where username='$uname' and stu_id='$_POST[stuid]'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
echo("username or student id already exists");
header("location:student.php?msg=notok");
}
else
{
move_uploaded_file($_FILES["file"]["tmp_name"], "UPLOAD/time/".$_FILES["file"]["name"]);
	//echo "Stored in:"."UPLOAD/time/".$_FILES["file"]["name"];
$insertquery="insert into student set stu_id='$_POST[stuid]' ,class_id='$_POST[cid]',section_id='$_POST[sid]',stu_name='$_POST[sname]',gender='$_POST[gender]',Father_Name='$_POST[fathername]',Mother_Name='$_POST[mothername]',
mobile_no='$_POST[mno]',username='$_POST[eid]',password='$_POST[pass]',address='$_POST[addr]',dob='$_POST[dob]',age='$_POST[age]',image='$filename',status='$_POST[status]'";
$exe1= mysql_query($insertquery);
$updatequery="update section set strength='$strength' where class_id='$_POST[cid]' and section_id='$_POST[sid]'";
$exe2=mysql_query($updatequery);
$insert="insert into parent set parent_id='$_POST[stuid]',Father_Name='$_POST[fathername]',Mother_Name='$_POST[mothername]',username='$_POST[eid]',password='$_POST[pass]',status='$_POST[status]'";
$exe3=mysql_query($insert);
//$inserta="insert into attandance set stu_id='$_POST[stuid]',stu_name='$_POST[sname]',class_id='$_POST[cid]',section_id='$_POST[sid]'";
//$exe4=mysql_query($inserta);
header("location:student.php?msg=ok");	//for redirecting page to new page after login success
}
}
?>
<?php
if(isset($_POST['submi']))

{
$date = date("Y-m-d h:i:s");
$insertquery="insert constactus set name='$_POST[name]',email_id='$_POST[email]',message='$_POST[txt_msg]',date='$date'";
$exe1= mysql_query($insertquery);
header("location:student.php?msg=ok");
}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style2.css" rel="stylesheet" type="text/css" />
<SCRIPT>
function getSection()
{
	var xmlhttp;
	
	if(window.XMLHttpRequest)
	{//code for IE7+,firefox,chorme,opera,safari
	 xmlhttp = new XMLHttpRequest();
	}
	else
	{//code for IE6,IE5
	xmlhttp = new ActiveXobject("Microsoft.XMLHTTP");
	}
	
var url = "funcs.php";
	
var classid = document.getElementById('classs').value;	


url = url +"?classid="+classid;

alert(url);

xmlhttp.open("GET", url, true);
xmlhttp.send();

	xmlhttp.onreadystatechange=function()
	{
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
			  {
				  document.getElementById("ssid").innerHTML=xmlhttp.responseText;
				   
			  }
		 }
}

</script>
<script>
function validateFormm()
{
var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class id   must be filled out");
  document.student.cid.focus();
 return false;
  }
  var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section d   must be filled out");
  document.student.cid.focus();
 return false;
  }
  var x=document.forms["student"]["stuid"].value;
if (x==null || x=="")
  {
  alert("student  id must be filled out");
   document.student.sname.focus();
 return false;
  }
var x=document.forms["student"]["sname"].value;
if (x==null || x=="")
  {
  alert("student  name must be filled out");
   document.student.sname.focus();
 return false;
  }
  
  var x=document.forms["student"]["fathername"].value;
if (x==null || x=="")
  {
  alert("father name must be filled out");
   document.student.sname.focus();
 return false;
  }
  var x=document.forms["student"]["mothername"].value;
if (x==null || x=="")
  {
  alert("mothername  name must be filled out");
   document.student.sname.focus();
 return false;
  }
  var x=document.forms["student"]["dob"].value;
if (x==null || x=="")
  {
  alert("date of birth must be filled out");
   document.student.dob.focus();
 return false;
  }
  var x=document.forms["student"]["pass"].value;
if (x==null || x=="")
  {
  alert("password must be filled out");
   document.student.pass.focus();
 return false;
  }
 
  if ((x.length < 4) || (x.length > 14))
{
alert("Your Password must be 4 to 8 Character");
document.student.pass.focus();
return false;
}

if((!document.student.gender[0].checked)&&(!document.student.gender[1].checked))
{
alert("gender must be selected");
document.student.gender[0].focus();
return false;
}
   
   var x=document.forms["student"]["age"].value;
if (x==null || x=="")
  {
  alert("dob must be filled out");
   document.student.age.focus();
 return false;
  }

  var x=document.forms["student"]["mno"].value;
if (x==null || x=="")
  {
  alert("contact no must be filled out");
   document.student.mno.focus();
 return false;
  }
  if ((x.length <10) || (x.length > 10))
{
alert("invalid mobile no");
document.teachers.mob.focus();
return false;
}
}
function ageCount() {
    var date1 = new Date();
	alert(date1);
    var dob = document.getElementById("dob").value;
    var date2 = new Date(dob);
	//alert(date2);
    //var pattern = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
    //Regex to validate date format (dd/mm/yyyy)       
    //if (pattern.test(dob)) {
        var y1 = date1.getFullYear();
        //getting current year            
        var y2 = date2.getFullYear();
        //getting dob year            
        var age = y1 - y2;
        //calculating age                       
        document.getElementById("ageId").value = age;
        doucment.getElementById("ageId").focus ();
        return true;
    //}
	//else {
       // alert("Invalid date format. Please Input in (mm/dd/yyyy) format!");
        //return false;
    //}

}
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function section()
{

  alert("these are the only section left which are not filled");
  document.student.sid.focus();
 return false;
  }
</script>
</head>


<body>
<div id="container">
<div id ="header"><img src="fcopy.png" height="100" width="100"/>
<h2>
ANDROID ACADEMIC ASSISTANT APPLICATION</h2></div>
<div id="home">
<ul>
	<li>
	<a href="index.php"><h3 style="color:white">Home </h3></a></li>
	<li>
	
		
		<a href="viewScore.php"><h3 style="color:white">ViewMarks</h3></a></li>
		<li>
		<a href="logout.php"><h3 style="color:white">Logout</H3></a></li>
		</ul>
</div>
<div id="leftmenu">
<marquee direction="up" >A student is a learner, or someone who attends an educational institution.<br/><br/><br/> 
In some nations, the English term (or its cognate in another language) is reserved for those who attend university<br/><br/><br/> 
while a schoolchild under the age of eighteen is called a pupil in English (or an equivalent in other languages)</br><br/><br/>although in the United States and in Australia a person enrolled in grades K12 is often called a student.<br/><br/><br/> 
 In its widest use, student is used for anyone who is learning, including mid-career adults who are taking vocational education or returning to university.</marquee>
		</div>
		
</div>
<div id="form3">
    <form name="student"action="" method="post" enctype="multipart/form-data" onSubmit="return validateFormm();">
<table border=0 cellspacing=0 cellpadding=2PX>
<?php

if(isset($_POST['submit']))
 {
$msg=$_GET['msg'];
if($msg=="notok")
{
	?><tr><td> <?php echo "Already Exists"; ?></td></tr>
<?php 
} 

}?>
 
<tr>
<td>ClassName:</td>
<td><select name="cid" id="classs" onChange="getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php classlist(); ?>
</select></td>
</tr>

<tr>
<td>sectionName:</td>
<td><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php  ?>
</select></td>
</tr>
<tr>
<td>STUDENT_ID:</td>
<td><input type="text" name="stuid"/>
</tr>

<tr>
<td>STUDENT_NAME:</td>
<td><input type="text" name="sname"/>
</tr>

<tr>
<td>Gender:</td>
<td><input type="radio" name="gender" value="M"> MALE
<input type="radio" name="gender" value="F">FEMALE</td>
</tr>
<tr>
<td>FATHER_NAME:</td>
<td><input type="text" name="fathername"/>
</tr>
<tr>
<td>MOTHER_NAME:</td>
<td><input type="text" name="mothername"/>
</tr>
<tr>
<td>Parent_Mobilno:</td>
<td><input type="text" name="mno" maxlength=10 onKeyPress="return isNumber(event);"></td>
</tr>
<tr>
<td>username:</td>
<td><input type="text" name="eid"></td>
</tr>
<tr>
<td>password:</td>
<td><input type="password" name="pass"/>
</tr>
<tr>
<td>Address:</td>
<td><input type="text" name="addr"></td>
</tr>

<tr>
<td>Date Of Birth</td>
<td><input type="date" name="dob" id="dob"/>mm/dd/yyyy</td>
</tr>
<tr>
<td>Age</td>
<td><input type="text" name="age" id="ageId" READONLY onfocus="ageCount();"/></td>
</tr>
<tr>
<td>IMAGE:</td>
<td><input type="file" name="file" id="file"></td>
</tr>
<tr>
<td>Status:</td>
<td><input type="text" name="status" READONLY id="status" VALUE="student"></td>
</tr>
<tr>
<td>
<input type="Submit" name="submit" value="submit">
</td>
</tr>
</table>
</form><br/><br/>

<?php
	
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM student";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);
?>
<table border>
<tr>
     <th>ClassID</th>
	 <th>SectionId</th>
	<th>studentName</th>
	
	<th>MobileNo</th>
	<th>username</th>
	<th>Address</th>
	<th>DOB</th>
	<th>AGE</th>
	<th>IMAGE</th>
</tr>

<?php
//number of results per page
$display=4;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM student $limitQ";
$result11=mysql_query($query11);


while($fetch=mysql_fetch_object($result11))
{?>
<tr><td><?php print "$fetch->class_id"?></td>
<td><?php print "$fetch->section_id"?></td>
	<td><?php print "$fetch->stu_name"?></td>
	<td><?php print "$fetch->mobile_no"?></td>
	<td><?php print "$fetch->username"?></td>
	<td><?php print "$fetch->address"?></td>
	<td><?php print "$fetch->dob"?></td>
	<td><?php print "$fetch->age"?></td>
	<td><img src="UPLOAD/<?php print "$fetch->image" ?> " alt ="<?php print "$fetch->image;" ?>" title="<?php echo "$fetch->image;" ?>" width="50" height="50" /></td>
 
	<td><a href= "editStudent.php?stu_id=<?php echo "$fetch->stu_id"?>&class_id=<?php echo "$fetch->class_id"?>&section_id=<?php echo "$fetch->section_id"?>">Edit  </a></td>
    <td><a href= "dlteStu.php?stu_id=<?php echo "$fetch->stu_id"?>&class_id=<?php echo "$fetch->class_id"?>&section_id=<?php echo "$fetch->section_id"?>">Delete  </a></td>
 </tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=student.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=student.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}
else{
$nextPage=$currentPage+1;
print "<a href=student.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=student.php?page=$lastPage>Last</a>";
}
?>
        </div>
  <div id="footer2">

</div>
<div id="followus">
<h3 STYLE="COLOR:RED">FOLLOW US</H3><BR/>
<a href="http://twitter.com"><img src="image/twitter.jpg" height="40" width="40"/></a><a href="http://facebook.com"><img src="image/fb.jpg" height="40" width="40"/></a>
<DIV id="contactus"><h3 STYLE="COLOR:RED">CONTACT US</H3><br/>EUREKA ELECTROSOFT SOLUTIONS Pvt.Ltd<br/>Plot No.: E-55, F1st floor<br/> Phase-8 Industrial Area<br/> Near C-DAC Mohali (Punjab)<br/>Ph.: 0172-4638606, 5091855<br/> M: 9815216606.</div>
<div id="Enquiry"><h3 STYLE="COLOR:RED">ENQUIRY</H3>
<form name="contact" method="post" onsubmit="return validate();">  
 Name*<br/><input name="name" type="text"   onfocus="if(this.value=='Your Name')this.value=''" onblur="if(this.value=='')this.value='Your Name'"/><BR/><BR/>
   Email_Id*<br/><input name="email" type="text"   onfocus="if(this.value=='Your E-mail Address')this.value=''" onblur="if(this.value=='')this.value='Your E-mail Address'"/><BR/><BR/>
    <textarea name="txt_msg"  rows="" cols="" onfocus="if(this.value=='Put your message here')this.value=''" onblur="if(this.value=='')this.value='Put your message here'">Put your message here</textarea><br/><br/>
   <INPUT TYPE="SUBMIT" NAME="submi" value="submit"/></form>
 </div>
</div>
<div id="footer1"> Copyright Information EESPL. All Rights Reserved.</div>
</DIV>

</body>
</html>