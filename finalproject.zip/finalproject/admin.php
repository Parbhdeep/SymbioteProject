<?php
include_once("session.php");
include_once("adminheader.php");
?>
<html>
<script>
function validateFormm()
{
var x=document.forms["student"]["uname"].value;
if (x==null || x=="")
  {
  alert("username must be filled out");
  document.student.uname.focus();
 return false;
  }
  var x=document.forms["student"]["pswd"].value;
if (x==null || x=="")
  {
  alert("password must be filled out");
  document.student.pswd.focus();
 return false;
  }
    var x=document.forms["student"]["cno"].value;
if (x==null || x=="")
  {
  alert("contact number must be filled out");
   document.student.cno.focus();
 return false;
  }
  if ((x.length <10) || (x.length > 10))
{
alert("invalid mobile no");
document.student.cno.focus();
return false;
}
var x=document.forms["student"]["afname"].value;
if (x==null || x=="")
  {
  alert("father name must be filled out");
   document.student.afname.focus();
 return false;
  }
  
  var x=document.forms["student"]["emailid"].value;
if (x==null || x=="")
  {
  alert("Email id must be filled out");
   document.student.emailid.focus();
 return false;
  }
 }
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function abcde()
{
	var b=document.student.pswd.value;
	var c=b.length;
	if(c<3||c>11)
	{
		alert("password length must be between 3 and 11");
	}
}
function inputLimiter(e,allow) {
    var AllowableCharacters = '';

    if (allow == 'Letters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';}
    if (allow == 'Numbers'){AllowableCharacters='1234567890';}
    if (allow == 'NameCharacters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-.\'';}
    if (allow == 'NameCharactersAndNumbers'){AllowableCharacters='1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-\'';}
	
    var k = document.all?parseInt(e.keyCode): parseInt(e.which);
    if (k!=13 && k!=8 && k!=0){
        if ((e.ctrlKey==false) && (e.altKey==false)) {
        return (AllowableCharacters.indexOf(String.fromCharCode(k))!=-1);
        } else {
        return true;
        }
    } else {
        return true;
    }
} 

</script>
<script>
var newwindow;
function poptastic(adminexcel.php)
{
newwindow=window.open(adminexcel.php,'name','height=400,width=200');
if(window.focus){newwindow.focus()}
}
</script>
<body bgcolor="#c0cec2" >

	
	  <link rel="stylesheet" href="style.css">
	  
<title>A4 Project</title>
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
<LI>
		<a href="adminexcel.php">Import using excel</a></li>
		<LI>
		<a href="school.php">Create School</a></li>
	     <LI>
		<a href="teacher.php">Create Teacher</a></li>
		</ul>
		</div>
		</div>
		</div>
		
</div>


<div id="form3">
	<center>
	<h2>Create Admin</h2>
    <form name="student" action="" method="post" enctype="multipart/form-data" onsubmit="return validateFormm();" >
	<table>
	</table>
<table border=0 cellspacing=0 cellpadding=2PX>

<td>ADMIN_username:</td>
<td><input type="text" name="uname" onkeypress="return inputLimiter(event,'NameCharacters')" placeholder="username" ></td>
</tr>
<tr>
<td>ADMIN_password:</td>
<td><input type="password" name="pswd" placeholder="password" onblur="return abcde();">
</tr>
<tr>
<td>contact_no</td>
<td><input type="text" name="cno" placeholder="contact_no" maxlength="10" onKeyPress="return isNumber(event);"></td>
</tr
<tr>
<td>admin_fathername</td>
<td><input type="text" name="afname"  onkeypress="return inputLimiter(event,'NameCharacters')" placeholder="Father Name"></td>
</tr>
<tr>
<td>email_id</td>
<td><input type="text" name="emailid" placeholder="Email id"></td>
</tr>
<tr>
<td>Status:</td>
<td><input type="text" name="status" READONLY id="status" VALUE="ADMIN"></td>
</tr>
<tr>
<td>
<input type="Submit" name="submit" value="submit">
</td>
</tr>
</table>
</center>
</form>
</div><br/><br/>

<?php
	include_once("db.php");
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM admin";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);
?>
<div id="table1">
<table border="">
<tr>
     <th>ADMIN_USERNAME</th>
	 <th>AD_F_NAME</th>	
	<th>CONTACT_NO</th>
	<th>EMAIL_ID</th>
		<th>DATE-TIME</th>

</tr>

<?php
//number of results per page
$display=4;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM admin $limitQ";
$result11=mysql_query($query11);


while($fetch=mysql_fetch_object($result11))
{?>
<tr><td><?php print "$fetch->admin_username"?></td>
<td><?php print "$fetch->admin_fname"?></td>
	<td><?php print "$fetch->contact_no"?></td>
	<td><?php print "$fetch->email_id"?></td>
	<td><?php print "$fetch->date_time"?></td>
 <td><a href= "adminedit.php?admin_id=<?php echo "$fetch->admin_id"?>">Edit  </a></td>
    <td><a href= "admindelete.php?admin_id=<?php echo "$fetch->admin_id"?>">Delete  </a></td
	
 </tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=admin.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=admin.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}
else{
$nextPage=$currentPage+1;
print "<a href=admin.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=admin.php?page=$lastPage>Last</a>";
}
?>
<?php
include_once("db.php");
$dtime=date("y-m-d h:i:s");
if(isset($_POST['submit']))
{
$user=$_POST['uname'];
$email=$_POST['emailid'];
$select="select * from admin where admin_username='$user' or email_id='$email'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Username already exist")';
print'</script>';

}
else
{
$sett="insert into admin set admin_username='$_POST[uname]',admin_password='$_POST[pswd]',
 admin_fname='$_POST[afname]',status='$_POST[status]',contact_no='$_POST[cno]',
email_id='$_POST[emailid]',date_time='$dtime'";
mysql_query($sett);

//mysql_query($updatequery);
}
}
?>
</div>
</body>
</html>
<?php
include_once("footer1.php");
?>
