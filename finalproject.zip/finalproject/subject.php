<?php
include_once("session.php");
include_once("schoolheader.php");
?>
<script>
function validateFormm()
{

var x=document.forms["subject"]["sname"].value;
if (x==null || x=="")
  {
  alert("subject name must be filled out");
  document.student.sname.focus();
 return false;
  }
var x=document.forms["subject"]["sid"].value;
if (x==null || x=="")
  {
  alert("subject id must be filled out");
  document.student.sid.focus();
 return false;
  }
}

</script>
<html>
<body bgcolor="#c0cec2">
<title>A4 Project</title>
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>
		<center>
		<h2>Enter Subject</h2>
		<div>
		<form name="subject" method="post" onsubmit="return validateFormm();">
		<table border="0" cellpadding="10" cellspacing="0" width="300" align="center">
		<tr>
		<td width="40%">subject name:</td>
		<td width="60%"><input type="text" name="sname" id="sname" placeholder="subject name"></br></td>
		</tr>
		<tr>
		   <td width="40%">subject id:</td>
		   <td width="60%"><input type="text" name="sid" id="sid" placeholder="subject Id" ></br></td>
			</tr>
			<tr>
			<td width="40%"><input type="submit" name="submit" value="submit"></td>
			<td width="40%"><input type="reset" name="clear" value="clear"></td>
			</tr>
			</form>
			</table>
			</center>
			</div>
<?php
include_once("db.php");
if(isset($_POST['submit']))
{
$subject=$_POST['sname'];
$sid=$_POST['sid'];
$select="select * from subject where subject_name='$subject' AND subject_id='$sid' ";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Subject already exist")';
print'</script>';

}
else
{
$sett="insert into subject set subject_name='$_POST[sname]',subject_id='$_POST[sid]'";
mysql_query($sett);

}
}
?>

<center>
<?php	
ob_start();
include_once("db.php");
//include_once("session.php");
//include_once("admin_navigation.php");


error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM subject";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);

?>
<div id="table">
<table border="" width="70%">
<tr>
	<th>SUBJECT ID</th>
	<th>SUBJECT NAME</th>
	
	
</tr>
<?php
//number of results per page
$display=2;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM subject $limitQ";
$result11=mysql_query($query11);



while($fetch=mysql_fetch_object($result11))
{?>
<tr><td><?php print "$fetch->subject_id"?></td>
	<td><?php print "$fetch->subject_name"?></td>
	
	
	<td><a href= "editsubject.php?subject_id=<?php print $fetch->subject_id;?>">Edit  </a></td>
    <td><a href= "dltesubject.php?subject_id=<?php print $fetch->subject_id;?>">Delete  </a></td>
	
</tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=subject.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=subject.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}else{
$nextPage=$currentPage+1;
print "<a href=subject.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=subject.php?page=$lastPage>Last</a>";
}
?>
</center>
</div>
</body>
</html>
<?php
include_once("footer1.php");
?>


