<?php
include_once("session.php");
ob_start();
include_once("teacherheader.php");
include_once("db.php");
include_once("getclass.php");
include_once("getsubjects.php");
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
$select121="Select * from test where test_id='$_GET[test_id]'"; 
$exe121=mysql_query($select121);
$fetch11=mysql_fetch_array($exe121); 
$abcde=$_GET[class_id];
$subj=$_GET[subject_id];
if(isset($_POST['submit']))

{
$select="select * from test where class_id='$_POST[cid]' && subject_id='$_POST[sub]' && section_id='$_POST[sid]'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{echo "already exists";
//header("location:editSubs.php?msg=notok");
}
else
{
$date = date("Y-m-d h:i:s");
$updatequery="update test set test_name='$_POST[test]',class_id='$_POST[cid]',section_id='$_POST[sid]',date='$date',subject_id='$_POST[sub]',marks='$_POST[marks]'
where test_id='$_GET[test_id]'";
$exe1= mysql_query($updatequery);

header("location:inserttest.php?msg=updated$test_id='$_GET[test_id]'");	//for redirecting page to new page after login success
}
}
?>
<?php
function se($cll)
{
$sell="select * from class";
$exee=mysql_query($sell);
while($fetchh=mysql_fetch_array($exee))
{
?>
<option value='<?php echo $fetchh['class_id'];?>'<?php if($fetchh['class_id']==$cll){ echo "selected='selected'";}?> ><?php echo $fetchh['class_name'];?></option>

<?php

}
}
?>
<?php
function sb($cll)
{
$sell="select * from subject";
$exee=mysql_query($sell);
while($fetchh=mysql_fetch_array($exee))
{
?>
<option value='<?php echo $fetchh['subject_id'];?>'<?php if($fetchh['subject_id']==$cll){ echo "selected='selected'";}?> ><?php echo $fetchh['subject_name'];?></option>

<?php

}
}
?>
<?php
function sect($cla)
{
$selll="select * from section where class_id='$cla'";
$exeee=mysql_query($selll);
while($fetchhh=mysql_fetch_array($exeee))
{?>
<option value='<?php echo $fetchhh['section_id'];?>'<?php if($fetchhh['class_id']==$cla){ echo "selected='selected'";}?> ><?php echo $fetchhh['section_name'];?></option>

<?php

}
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />

<script>

function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="getsection.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}

</script>
<script>
function validateFormm()
{
var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class id   must be filled out");
  document.student.cid.focus();
 return false;
  }
var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section id  must be filled out");
   document.student.sid.focus();
 return false;
  }
  var x=document.forms["student"]["test"].value;
if (x==null || x=="")
  {
  alert("Test name must be filled out");
   document.student.test.focus();
 return false;
  }
  var x=document.forms["student"]["sub"].value;
if (x==null || x=="")
  {
  alert("subject must be filled out");
   document.student.sub.focus();
 return false;
  }
  var x=document.forms["student"]["marks"].value;
if (x==null || x=="")
  {
  alert("Total marks must be filled out");
   document.student.marks.focus();
 return false;
  }
   }


function section()
{

  alert("these are the only section left which are not filled");
  document.student.sid.focus();
 return false;
  }
</script>
</head>

<body bgcolor="#c0cec2">


<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
			<LI>
		<a href="inserttest.php">Create Test</a></li>
		<li>
      <a href="attendence.php">Mark Attendence</a></li>
	  
	<LI>
		<a href="test1.php">Insert Marks</a></li>
		
		</ul>		
		</div>
		</div>
		</div>

<div id="form3">
<center>
<h2>Edit Test</h2>
   <form name="student"action="" method="post" enctype="multipart/form-data" onSubmit="return validateFormm();">
   

   <table border=0 CELLSPACING=0 CELLPADDING=2px>
<?php

if(isset($_POST['submit']))
 {
$msg=$_GET['msg'];
if($msg=="notok")
{
	?><tr><td> <?php echo "Already Exists"; ?></td></tr>
<?php 
} 

}?>
 <tr>
<td>TestName:</td>
<td><input type="text" name="test" id="test" value="<?php echo $fetch11['test_name'] ?>"></td>
</tr>
 
<tr>
<td>ClassName:</td>
<td><select name="cid" id="classs" onChange="getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php se($abcde); ?>
</select></td>
</tr>

<tr>
<td>sectionName:</td>
<td><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php sect($abcde);  ?>
</select></td>
</tr>
<tr>
<td>subName:</td>
<td><select name="sub" id="sub">
<OPTION VALUE="">---select subject---</OPTION>
<?php sb($subj);?></td>
</select>

<tr>
<td>TotalMarks:</td>
<td><input type="text" name="marks" value="<?php echo $fetch11['marks'] ?>">
</tr>


<tr>
<td>
<input type="Submit" name="submit" value="submit">
</td>
</tr>
</center>
</table>
</form><BR/><BR/>
<?php
include_once("footer2.php");
?>