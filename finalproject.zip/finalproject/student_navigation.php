<?php
ob_start();
include_once("session.php");
include_once("db.php");
include_once("studentheader.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
var image1 = new Image()
image1.src = "image/school_building.jpg"
var image2 = new Image()
image2.src = "image/image4.jpg"
var image3 = new Image()
image3.src = "image/image5.jpg"
var image4 = new Image()
image4.src = "image/image1.jpg"
var image5 = new Image()
image5.src = "image/edu3.jpg"
var image6 = new Image()
image6.src = "image/image2.jpg"
function validate()
{
var x=document.contact.name.value;
if(x==""||x==null)
{
alert("fill ur name");
document.contact.name.focus();
 return false;
 }
 var x=document.contact.email.value;
if(x==""||x==null)
{
alert("fill ur emailid");
document.contact.email.focus();
 return false;
}
}

</script>
</head>
<body bgcolor="#c0cec2">
<div id="leftmenu1">
<marquee direction="up" >A student is a learner, or someone who attends an educational institution.<br/><br/><br/> 
In some nations, the English term (or its cognate in another language) is reserved for those who attend university<br/><br/><br/> 
while a schoolchild under the age of eighteen is called a pupil in English (or an equivalent in other languages)</br><br/><br/>although in the United States and in Australia a person enrolled in grades K12 is often called a student.<br/><br/><br/> 
 In its widest use, student is used for anyone who is learning, including mid-career adults who are taking vocational education or returning to university.</marquee>
		</div>
		
</div>
<p><img src="image/school_building.jpg" width="550" height="300" name="slide" /></p>
<script type="text/javascript">
        var step=1;
        function slideit()
        {
            document.images.slide.src = eval("image"+step+".src");
            if(step<6)
                step++;
            else
                step=1;
            setTimeout("slideit()",3500);
        }
        slideit();
</script>
</p>
<div id="spacer">
</div>
<?php
include_once("footer1.php");
?>
</body>
</html>