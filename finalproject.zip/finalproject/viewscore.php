<?php
include_once("session.php");
include_once("db.php");
include_once("studentheader.php");
//include_once("funcScore");
//include_once("funcsubject");
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
if(isset($_POST['search']))
{
$selectQuery="select * from studentScore where stu_id='$_POST[sid]'";
$exe=mysql_query($selectQuery);

?>
<center><table border=0>
<tr><td>StudentId</td><td>Subjectid</td><td>score</td></tr>
<?php
 
while( $result111 = mysql_fetch_array($exe))
{
?>
	
	<tr><td><?php echo $result111['stu_id'];?></td> <td><?php echo $result111['subject_id'];?></td> <td><?php echo $result111['score'];?></TD></tr>
	
<?php }} ?>
</table> </center>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />


<script>
var image1 = new Image()
image1.src = "image/school_building.jpg"
var image2 = new Image()
image2.src = "image/image4.jpg"
var image3 = new Image()
image3.src = "image/image5.jpg"
var image4 = new Image()
image4.src = "image/image1.jpg"
var image5 = new Image()
image5.src = "image/edu3.jpg"
var image6 = new Image()
image6.src = "image/image2.jpg"
function validateFormm()
{
var x=document.forms["teachers"]["tname"].value;
if (x==null || x=="")
  {
  alert("teachers  name must be filled out");
 return false;
  }
  var x=document.forms["teachers"]["mob"].value;
if (x==null || x=="")
  {
  alert("contact no must be filled out");
 return false;
  }
  if ((x.length <10) || (x.length > 10))
{
alert("invalid mobile no");
document.teachers.mob.focus();
return false;
}

//}
//function validateForm()
//{
var x=document.forms["teachers"]["eid"].value;
var atpos=x.indexOf("@");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
  
}
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

</script>
<script>
function getMarks()
{
//alert("helllo");
	var xmlhttp;
	
	if(window.XMLHttpRequest)
	{//code for IE7+,firefox,chorme,opera,safari
	 xmlhttp = new XMLHttpRequest();
	}
	else
	{//code for IE6,IE5
	xmlhttp = new ActiveXobject("Microsoft.XMLHTTP");
	}
	
var url = "getscore.php";
	
var stuid = document.getElementById('sid').value;	


url = url +"?stuid="+stuid;

//alert(url);

xmlhttp.open("GET", url, true);
xmlhttp.send();

	xmlhttp.onreadystatechange=function()
	{
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
			  {
				  document.getElementById("testt").innerHTML=xmlhttp.responseText;
				   
			  }
		 }
}
</script>
</head>

<body bgcolor="#c0cec2" >
<h2 align="left">View Marks</h2>
<p><img src="images/school_building.jpg" width="550" height="300" name="slide" /></p>
<script type="text/javascript">
        var step=1;
        function slideit()
        {
            document.images.slide.src = eval("image"+step+".src");
            if(step<6)
                step++;
            else
                step=1;
            setTimeout("slideit()",3500);
        }
        slideit();
</script>
</p>

</div>
<div id="form">

<form name="score" method="post" align="left">
StudentId:<input type="text" name="sid" id="sid" placeholder="Enter Id" />

<input type="button" name="search" value="search"/ onclick="getMarks();"><br/></br>
<div id="testt"></div>
</div> 
<div id="spacer">
</div>
<?php
include_once("footer1.php");
?>
</body>
</html>
