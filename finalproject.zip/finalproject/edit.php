<?php
include_once("session.php");
include_once("schoolheader.php");
include_once("db.php");
$sett="select * from student_id where stu_id='$_GET[stu_id]'";
$exe=mysql_query($sett);
$fetch=mysql_fetch_array($exe);
$abcde=$_GET[class_id];
if(isset($_POST['submit']))
{
$filename=$_FILES['file']['name'];
move_uploaded_file($_FILES["file"]["tmp_name"], "UPLOAD/".$_FILES["file"]["name"]);
echo $up="update student_id set stu_id='$_POST[stuid]',class_id='$_POST[cid]',section_id='$_POST[sid]',username='$_POST[eid]',password='$_POST[pass]',
address='$_POST[addr]',DOB='$_POST[dob]',age='$_POST[age]',status='$_POST[status]',stu_name='$_POST[sname]',
gender='$_POST[gender]',f_name='$_POST[fathername]',m_name='$_POST[mothername]',p_mobile='$_POST[mno],
where stu_id='$_GET[stuid]'";
$exe1= mysql_query($up);
header("location:section.php");
}
function se($cll)
{
$sell="select * from class";
$exee=mysql_query($sell);
while($fetchh=mysql_fetch_array($exee))
{
?>
<option value='<?php echo $fetchh['class_id'];?>'<?php if($fetchh['class_id']==$cll){ echo "selected='selected'";}?> ><?php echo $fetchh['class_name'];?></option>

<?php

}
}
?>
<?php
function sect($cla)
{
$selll="select * from section where class_id='$cla'";
$exeee=mysql_query($selll);
while($fetchhh=mysql_fetch_array($exeee))
{?>
<option value='<?php echo $fetchhh['section_id'];?>'<?php if($fetchhh['class_id']==$cla){ echo "selected='selected'";}?> ><?php echo $fetchhh['section_name'];?></option>

<?php

}
}
?>
	<script>
	function validateFormm()
{
var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class id   must be filled out");
  document.student.cid.focus();
 return false;
  }
  var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section id   must be filled out");
  document.student.cid.focus();
 return false;
  }
  var x=document.forms["student"]["stuid"].value;
if (x==null || x=="")
  {
  alert("student  id must be filled out");
   document.student.sname.focus();
 return false;
  }
var x=document.forms["student"]["sname"].value;
if (x==null || x=="")
  {
  alert("student  name must be filled out");
   document.student.sname.focus();
 return false;
  }
  
  var x=document.forms["student"]["fathername"].value;
if (x==null || x=="")
  {
  alert("father name must be filled out");
   document.student.sname.focus();
 return false;
  }
  var x=document.forms["student"]["mothername"].value;
if (x==null || x=="")
  {
  alert("mothername  name must be filled out");
   document.student.sname.focus();
 return false;
  }
  var x=document.forms["student"]["dob"].value;
if (x==null || x=="")
  {
  alert("date of birth must be filled out");
   document.student.dob.focus();
 return false;
  }
  var x=document.forms["student"]["pass"].value;
if (x==null || x=="")
  {
  alert("password must be filled out");
   document.student.pass.focus();
 return false;
  }
 
   var x=document.forms["student"]["age"].value;
if (x==null || x=="")
  {
  alert("age must be filled out");
   document.student.age.focus();
 return false;
  }

  var x=document.forms["student"]["mno"].value;
if (x==null || x=="")
  {
  alert("contact no must be filled out");
   document.student.mno.focus();
 return false;
  }
    if ((x.length <10) || (x.length > 10))
{
alert("invalid mobile no");
document.teachers.mob.focus();
return false;
}
}
function abc()
{
var currentd=new Date();
//alert(currentd);
var dobb=document.student.dob.value;
var d=new Date(dobb);
var y1=currentd.getFullYear();
var y2=d.getFullYear();
var y3=y1-y2;
document.student.age.value=y3;

}
function abcd()
{
var a=document.student.eid.value;
if(a=="")
{
alert("username must be filled");
document.student.eid.focus();
}
}
function abcde()
{
	var b=document.student.pass.value;
	var c=b.length;
	if(c<3||c>11)
	{
		alert("password length must be between 3 and 11");
	}
}
function abcdef()
{
	if((!document.student.gender[0].checked)&&(!document.student.gender[1].checked))
	{
		alert("specify gender");
	}
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function inputLimiter(e,allow) {
    var AllowableCharacters = '';

    if (allow == 'Letters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';}
    if (allow == 'Numbers'){AllowableCharacters='1234567890';}
    if (allow == 'NameCharacters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-.\'';}
    if (allow == 'NameCharactersAndNumbers'){AllowableCharacters='1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-\'';}
	
    var k = document.all?parseInt(e.keyCode): parseInt(e.which);
    if (k!=13 && k!=8 && k!=0){
        if ((e.ctrlKey==false) && (e.altKey==false)) {
        return (AllowableCharacters.indexOf(String.fromCharCode(k))!=-1);
        } else {
        return true;
        }
    } else {
        return true;
    }
} 
</script>

<html>
<body bgcolor="#c0cec2" >

<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>

<title>A4 Project</title>
<center>
<h2>Edit Student</h2>
    <form name="student" action="" method="POST" enctype="multipart/form-data"  onSubmit="return validateFormm();">
<table>
</table>
<table>
</table>	
<table border=0 cellspacing=0 cellpadding=2PX>
<tr>
<td>ClassName:</td>
<td><select name="cid" id="classs">
<OPTION VALUE="">---select class---</OPTION>
<?php se($abcde); ?>
</select></td>
</tr>

<tr>
<td>sectionName:</td>
<td><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php sect($abcde);?>
</select></td>
</tr>
<tr>
<td>STUDENT_ID:</td>
<td><input type="text" name="stuid" value="<?php echo $fetch['stu_id'];?>">
</tr>

<tr>
<td>STUDENT_NAME:</td>
<td><input type="text" name="sname" onkeypress="return inputLimiter(event,'NameCharacters')" value="<?php echo $fetch['stu_name']?>">
</tr>

<tr>
<td>Gender:</td>
<td><input type="radio" name="gender" value="M" <?php if($fetch['gender'] == "M") {echo "checked='checked'";}?>> MALE
<input type="radio" name="gender" value="F" <?php if($fetch['gender'] == "F") {echo "checked='checked'";}?>>FEMALE</td>
</tr>
<tr>
<td>FATHER_NAME:</td>
<td><input type="text" name="fathername"  onkeypress="return inputLimiter(event,'NameCharacters')" value="<?php echo $fetch['f_name']?>" onfocus="return abcdef();">
</tr>
<tr>
<td>MOTHER_NAME:</td>
<td><input type="text" name="mothername"  onkeypress="return inputLimiter(event,'NameCharacters')" value="<?php echo $fetch['m_name']?>">
</tr>
<tr>
<td>Parent_Mobilno:</td>
<td><input type="text" name="mno" maxlength=10 value="<?php echo $fetch['p_mobile']?>" maxlength=10 onKeyPress="return isNumber(event);"></td>
</tr>
<tr>
<td>username:</td>
<td><input type="text" name="eid" value="<?php echo $fetch['username']?>" onblur="return abcd();"/></td>
</tr>
<tr>
<td>password:</td>
<td><input type="password" name="pass" value="<?php echo $fetch['password']?>" onblur="return abcde();"/>
</tr>
<tr>
<td>Address:</td>
<td><input type="text" name="addr" value="<?php echo $fetch['address']?>"></td>
</tr>

<tr>
<td>Date Of Birth</td>
<td><input type="date" name="dob" id="dob" value="<?php echo $fetch['DOB']?>">mm/dd/yyyy</td>
</tr>
<tr>
<td>Age</td>
<td><input type="text" name="age" id="ageId" value="<?php echo $fetch['age']?>"></td>
</tr>

<tr>
<td>Status:</td>
<td><input type="text" name="status" READONLY id="status" VALUE="student"></td>
</tr>
<tr>
<td>
<input type="Submit" name="submit" value="update">
</td>
</tr>
</center>
</table>
</form><br/><br/>
</body>
</html>
<?php
include_once("footer1.php");
?>
