<?php 
include_once("db.php");
function func1()
{
$sel="select * from class";
$exe=mysql_query($sel);
while($fetch=mysql_fetch_array($exe))
{
?>
<option value="<?php echo $fetch['class_id'];?>">
<?php echo $fetch['class_name'];?>
</option>
<?php
}
}
?>
