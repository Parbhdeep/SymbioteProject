<?php
include_once("session.php");
ob_start();
include_once("db.php");
include_once("getclass.php");
include_once("getsubjects.php");
include_once("teacherheader.php");

if(isset($_POST['submit']))
{


$select="select * from test where test_name='$_POST[test]'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
echo("test name already exists");
header("location:inserttest.php?msg=notok");
}
else
{
$date = date("Y-m-d h:i:s");
$insertquery="insert into  test set test_name='$_POST[test]',class_id='$_POST[cid]',section_id='$_POST[sid]',date='$date',subject_id='$_POST[sub]',marks='$_POST[marks]'";
$exe1= mysql_query($insertquery);

header("location:inserttest.php?msg=ok");	//for redirecting page to new page after login success
}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />

<script>

function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="getsection.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}

</script>
<script>
function validateFormm()
{
var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class id   must be filled out");
  document.student.cid.focus();
 return false;
  }
var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section id  must be filled out");
   document.student.sid.focus();
 return false;
  }
  var x=document.forms["student"]["test"].value;
if (x==null || x=="")
  {
  alert("Test name must be filled out");
   document.student.test.focus();
 return false;
  }
  var x=document.forms["student"]["sub"].value;
if (x==null || x=="")
  {
  alert("subject must be filled out");
   document.student.sub.focus();
 return false;
  }
  var x=document.forms["student"]["marks"].value;
if (x==null || x=="")
  {
  alert("Total marks must be filled out");
   document.student.marks.focus();
 return false;
  }
   }


function section()
{

  alert("these are the only section left which are not filled");
  document.student.sid.focus();
 return false;
  }
</script>
</head>

<body bgcolor="#c0cec2">

<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
			<LI>
		<a href="inserttest.php">Create Test</a></li>
		<li>
      <a href="attendence.php">Mark Attendence</a></li>
	  
	<LI>
		<a href="test1.php">Insert Marks</a></li>
		
		</ul>		
		</div>
		</div>
		</div>
		

<div id="form3">
<center>
<h2>Add Test</h2>
   <form name="student"action="" method="post" enctype="multipart/form-data" onSubmit="return validateFormm();">

   <table border=0 CELLSPACING=0 CELLPADDING=2px>
<?php

if(isset($_POST['submit']))
 {
$msg=$_GET['msg'];
if($msg=="notok")
{
	?><tr><td> <?php echo "Already Exists"; ?></td></tr>
<?php 
} 

}?>
 <tr>
<td>TestName:</td>
<td><input type="text" name="test" id="test" placeholder="test name"/></td>
</tr>
 
<tr>
<td>ClassName:</td>
<td><select name="cid" id="classs" onChange="getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php sctn(); ?>
</select></td>
</tr>

<tr>
<td>sectionName:</td>
<td><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php  ?>
</select></td>
</tr>
<tr>
<td>subName:</td>
<td><select name="sub" id="sub">
<OPTION VALUE="">---select subject---</OPTION>
<?php sub();  ?></td>
</select>

<tr>
<td>TotalMarks:</td>
<td><input type="text" name="marks"placeholder="total marks"/>
</tr>


<tr>
<td>
<input type="Submit" name="submit" value="submit">
</td>
</tr>
</center>
</table>
</form><BR/><BR/>

<?php
	
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM test";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);
?>
<center>
<table border>
<tr>
     <th>TestName</th>
	 <th>Date</th>
	<th>classId</th>
	<th>sectionId</th>
	<th>subjectId</th>
	<th>Marks</th>
</tr>

<?php
//number of results per page
$display=2;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM test $limitQ";
$result11=mysql_query($query11);


while($fetch=mysql_fetch_object($result11))
{

$abc="select * from class where class_id='$fetch->class_id'";
$def=mysql_query($abc);
$ab=mysql_fetch_array($def);

$abcd="select * from section where section_id='$fetch->section_id'";
$defg=mysql_query($abcd);
$abb=mysql_fetch_array($defg);

?>
<tr><td><?php print "$fetch->test_name"?></td>
<td><?php print "$fetch->date"?></td>
	<td><?php print $ab['class_name'];?></td>
	<td><?php print $abb['section_name'];?></td>
	<td><?php print "$fetch->subject_id"?></td>
	<td><?php print "$fetch->marks"?></td>
	<td><a href= "edittest.php?test_id=<?php echo $fetch->test_id;?>&class_id=<?php echo $fetch->class_id;?>&section_id=<?php echo $fetch->section_id;?>&subject_id=<?php echo $fetch->subject_id;?>">Edit  </a></td>
    <td><a href= "dltetest.php?test_id=<?php echo "$fetch->test_id"?>">Delete  </a></td>
 </tr>
 <?php } ?>

</table>
</center>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=inserttest.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=inserttest.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}else{
$nextPage=$currentPage+1;
print "<a href=inserttest.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=inserttest.php?page=$lastPage>Last</a>";
}
?>
    </div>
</body>
</html>
<?php
include_once("footer1.php");
?>
