<?php
include_once("session.php");
ob_start();
include_once("db.php");

$delquery="delete from section where section_id='$_GET[section_id]'";
$exe1= mysql_query($delquery);

header("location:sections.php?msg=deleted$section_id='$_GET[section_id]'");	//for redirecting page to new page after login success

?>