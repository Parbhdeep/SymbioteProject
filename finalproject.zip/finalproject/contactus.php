<?php
include_once("indexheader.php");
include_once("session.php");
?>
<html>
<script>

function validate()
{
var x=document.contact.name.value;
if(x==""||x==null)
{
alert("fill ur name");
document.contact.name.focus();
 return false;
 }
 var x=document.contact.email.value;
if(x==""||x==null)
{
alert("fill ur emailid");
document.contact.email.focus();
 return false;
}
}


</script>
<body >
<link href="style.css" rel="stylesheet" type="text/css">

<div id="followus">
<table>
</table>
<table border="0" width="100%" height="10%" cellspacing="0" cellpadding="10" background="" >
<tr bgcolor=""><th class="style1"><center>Follow US</center></th>
<th class="style1">Contact US</th>
<th class="style1">Enquiry</th>
</tr>
<tr bgcolor="grey">
<td ><img border="0" src="image/fb.jpg" width="100" height="70">
<img border="0" src="image/twitter.jpg" width="100" height="60"></td>
<td class="style3">
EUREKA ELECTROSOFT SOLUTIONS Pvt.Ltd<br/>
Plot No.: E-55, F1st floor<br/>
Phase-8 Industrial Area<br/> 
Near C-DAC Mohali (Punjab)<br/>
Ph.: 0172-4638606, 5091855<br/>
 M: 9815216606.
</td>
<td class="style3">

<form name="contact" method="post" onsubmit="return validate();">  
 Name*<br/><input name="name" type="text"   onfocus="if(this.value=='Your Name')this.value=''" onblur="if(this.value=='')this.value='Your Name'"/><BR/><BR/>
   Email_Id*<br/><input name="email" type="text"   onfocus="if(this.value=='Your E-mail Address')this.value=''" onblur="if(this.value=='')this.value='Your E-mail Address'"/><BR/><BR/>
    <textarea name="txt_msg" onfocus="if(this.value=='Put your message here')this.value=''" onblur="if(this.value=='')this.value='Put your message here'">Put your message here</textarea><br/><br/>
   <INPUT TYPE="SUBMIT" NAME="submit" value="submit"/></form>

</td>
</tr>
</table>
</div>
</body>
<?php
ob_start();
include_once("db.php");
if(isset($_POST['submit']))

{
$date = date("Y-m-d h:i:s");
$insertquery="insert into contactus set name='$_POST[name]',email_id='$_POST[email]',message='$_POST[txt_msg]',date='$date'";
$exe1= mysql_query($insertquery);
}
?>
</html>