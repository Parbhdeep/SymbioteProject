<?php
ob_start();
include_once("db.php");
$classid=$_GET['classid'];
$testtid=$_GET['testtid'];
//echo $classid;
$sectionid=$_GET['sectionid'];
$subid=$_GET['subid'];
$score=explode(",",$_GET['score']);
//print_r($score);die;



//$timestamp = strtotime($string);
$date = date("m");
//$month=$_GET['month'];
$select33="Select stu_id,username from student_id where class_id='$classid' and section_id='$sectionid'"; 
$exe33=mysql_query($select33);

	//$data[]=$row;
	//$i_query="insert into attandance set stu_id='".$row[0]."' ,stu_name='".$row[1]."',date='$date',status='$status'";
          //  $i_result = mysql_query ($i_query);
		  



/*echo  $rows=mysql_num_rows($exe33);

        for ($i=0; $i<$rows; $i++) {


            $stu_info = "student_".$i;
            list($stu_id,,,$name,,,,,,,,) = $$emp_info;    
            
            
$i_query="insert into attandance set stu_id='$stu_id' ,stu_name='$name',date='$date',status='$status'";
            $i_result = mysql_query ($i_query);
}*/
$i=0;
while($row=mysql_fetch_array($exe33)){
	$data[]=$row;
	$i_query="insert into studentscore set stu_id='".$row[0]."' ,username='".$row[1]."' ,test_id='$testtid',subject_id='$subid',score='".$score[$i]."'";
           $i_result = mysql_query ($i_query);
	$i++;	 
}

//echo "Sucessfully enter !";
//echo "<pre>";print_r($data);
?>