<?php
	ob_start();
	include_once("db.php");
	include_once("indexheader.php");
	error_reporting(E_ALL^(E_NOTICE|E_WARNING));
	//include_once("session.php");
	//$status=$_GET['status'];
	
	$sellogin="select * from admin where admin_username='$_POST[user]'&& admin_password='$_POST[pswd]'";
	$exelogin=mysql_query($sellogin);
	$fetchlogin=mysql_fetch_array($exelogin);
	$row=mysql_num_rows($exelogin);
	
	$stulogin="select * from student_id where username='$_POST[user]'&& password='$_POST[pswd]'";
	$exestulogin=mysql_query($stulogin);
	$fetchlog=mysql_fetch_array($exestulogin);
	$rows=mysql_num_rows($exestulogin);
	$schlogin="select * from school where username='$_POST[user]'&& password='$_POST[pswd]'";
	$exeschlogin=mysql_query($schlogin);
	$fetchlogg=mysql_fetch_array($exeschlogin);
	$row1=mysql_num_rows($exeschlogin);
	$tealogin="select * from teachers where username='$_POST[user]'&& password='$_POST[pswd]' ";
	$exetealogin=mysql_query($tealogin);
	$fetchloggg=mysql_fetch_array($exetealogin);
	$row2=mysql_num_rows($exetealogin);
	if(isset($_POST['btnlogin']))
	{
	if($row==1)
	{
	/*if($fetchlogin['status']=="superadmin" && $fetchlogin['ad_username']==$_POST['user']&& $fetchlogin['ad_password']==$_POST['pswd'])
	//{
		session_start();
		$_SESSION['status']="superadmin";
		header("location:superad_work.php");
	}*/
session_start();
	$_SESSION['status']="admin";
	header("location:admin_navigation.php");
	}
	
	/*else if($fetchlogin['status']=="admin" && $fetchlogin['ad_username']==$_POST['user'] && $fetchlogin['ad_password']==$_POST['pswd'])
	{
		session_start();
		$_SESSION['status']="admin";
		header("location:superad_work.php");
	}
	*/
	
	else if($rows==1)
	{
	session_start();
	$_SESSION['status']="student";
	header("location:student_navigation.php");
	}
	else if($row1==1)
	{
	session_start();
	$_SESSION['status']="school";
	header("location:school_navigation.php");
	}
	else if($row2==1)
	{
	session_start();
	$_SESSION['status']="teacher";
	header("location:teacher_navigation.php");
	}
	else
	{
	print'<script type="text/javascript">';
    print'alert("Wrong username or password")';
    print'</script>';
	}
	}
	/*else if($fetchlog['status']=="student" &&$fetchlog['username']==$_POST['user']&& $fetchlog['password']==$_POST['pswd'])
	{
		session_start();
		$_SESSION['status']="student";
		header("location:student_navigation.php");
	}

	else if($fetchlogg['status']=="school" && $fetchlogg['username']==$_POST['user']&& $fetchlogg['password']==$_POST['pswd'])
	{
		session_start();
		$_SESSION['status']="school";
		header("location:school_navigation.php");
	}
	else if($fetchloggg['status']=="teacher" &&$fetchloggg['password']==$_POST['pswd']&& $fetchloggg['password']==$_POST['pswd'])
	{
		session_start();
		$_SESSION['status']="teacher";
		header("location:teacher_navigation.php");
	}
	else
	{
		echo "Login Unsuccessful wrong username or password";
	}
	
	}
	*/
?>

<?php

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript">
var image1 = new Image()
image1.src = "image/school_building.jpg"
var image2 = new Image()
image2.src = "image/image4.jpg"
var image3 = new Image()
image3.src = "image/image5.jpg"
var image4 = new Image()
image4.src = "image/edu5.jpg"
var image5 = new Image()
image5.src = "image/edu7.jpg"
var image6 = new Image()
image5.src = "image/edu6.jpg"
	function validation()
{
var a = document.loginn.pswd.value;
if(a=="")
{
alert("Please Enter Your Password");
document.signup.pass.focus();
return false;
}
//if ((a.length < 4) || (a.length > 8))
//{
//alert("Your Password must be 4 to 8 Character");
//document.signup.pass.select();
//return false;
//}
}
</script> 
</head>

<body bgcolor="#c0cec2">
    <div id="leftmenu1">
<marquee direction="up" scrollamount=2 >Android Academic Assistant Application (A4) is a comprehensive<BR> web based android notification software which is being developed to provide a <BR/>world class solution for academic interactionof parents with the most affordable <BR/>and most popular way of communication i.e Smartphone notification and Internet mailing.<BR/><BR/><BR/> In this present era, where people have so busy lives it has become so difficult for parents <BR/>to do regular interaction with the academics of their children. As a result, there<BR/> has been created a big communication gap between the teachers and parents.<BR/><BR/><BR/> In order to reduce this gap and to make the parents time to time aware of their child�s performance and of the various events and occurrences in the school in an easy and effective way there must be an affordable solution. 
		</MARQUEE>
		</div>
		 <p><img src="image/school_building.jpg" width="500" height="250" name="slide" /></p>
<script type="text/javascript">
        var step=1;
        function slideit()
        {
            document.images.slide.src = eval("image"+step+".src");
            if(step<5)
                step++;
            else
                step=1;
            setTimeout("slideit()",3500);
        }
        slideit();
</script>
</p> 
<div id="form1" align="">
LOGIN<BR/><BR/>
    <form name="loginn" method="post" onblur="return validation();">

Username:</td><td><input type="text" name="user" placeholder="username" >
Password:</td><td><input type="password" name="pswd" placeholder="password" >

<input type="submit" value="Login" name="btnlogin">
<?php
$tea="select * from teachers where username='$_POST[user]'&& password='$_POST[pswd]' ";
	$exetea=mysql_query($tea);
	$fgg=mysql_fetch_array($exetea);
?>
</form>
</body>
   </div>
<?php
include_once("footer1.php");
?>
</html>