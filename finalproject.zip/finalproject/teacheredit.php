<?php
include_once("session.php");
include_once("db.php");
include_once("adminheader.php");
$sett="select * from teachers where teacher_id='$_GET[teacher_id]'";
$exe=mysql_query($sett);
$fetch=mysql_fetch_array($exe);
if(isset($_POST['submit']))
{
$user=$_POST['uname'];
$email=$_POST['emailid'];
$select="select * from teachers where username='$user' or email_id='$email'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Username already exist")';
print'</script>';

}
else
{
$up="update teachers set teacher_id='$_POST[tid]',teacher_name='$_POST[tname]',username='$_POST[uname]',password='$_POST[pswd]',status='$_POST[status]',contact_no='$_POST[cno]',
email_id='$_POST[emailid]'

where teacher_id='$_GET[teacher_id]'";

mysql_query($up);
header("location:teacher.php?msg=updated$teacher_id='$_GET[teacher_id]'");	
}
}
?>
<script>
function validateFormm()
{
var x=document.forms["student"]["uname"].value;
if (x==null || x=="")
  {
  alert("username must be filled out");
  document.student.uname.focus();
 return false;
  }
  var x=document.forms["student"]["pswd"].value;
if (x==null || x=="")
  {
  alert("password must be filled out");
  document.student.pswd.focus();
 return false;
  }
    var x=document.forms["student"]["cno"].value;
if (x==null || x=="")
  {
  alert("contact number must be filled out");
   document.student.cno.focus();
 return false;
  }
  if ((x.length <10) || (x.length > 10))
{
alert("invalid mobile no");
document.student.cno.focus();
return false;
}  
  var x=document.forms["student"]["emailid"].value;
if (x==null || x=="")
  {
  alert("Email id must be filled out");
   document.student.emailid.focus();
 return false;
  }
 }
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function abcde()
{
	var b=document.student.pswd.value;
	var c=b.length;
	if(c<3||c>11)
	{
		alert("password length must be between 3 and 11");
	}
}
function inputLimiter(e,allow) {
    var AllowableCharacters = '';

    if (allow == 'Letters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';}
    if (allow == 'Numbers'){AllowableCharacters='1234567890';}
    if (allow == 'NameCharacters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-.\'';}
    if (allow == 'NameCharactersAndNumbers'){AllowableCharacters='1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-\'';}
	
    var k = document.all?parseInt(e.keyCode): parseInt(e.which);
    if (k!=13 && k!=8 && k!=0){
        if ((e.ctrlKey==false) && (e.altKey==false)) {
        return (AllowableCharacters.indexOf(String.fromCharCode(k))!=-1);
        } else {
        return true;
        }
    } else {
        return true;
    }
} 

</script>
<html>
<body bgcolor="#c0cec2">
<title>A4 Project</title>
	  <link rel="stylesheet" href="style.css">
	  	  <div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
<LI>
		<a href="teacherexcel.php">Import using excel</a></li>
		<LI>
		<a href="school.php">Create School</a></li>
		<LI>
		<a href="admin.php">Create Admin</a></li>
	</ul>
		</div>
		</div>
		</div>

<div id="form3">
	<center>
	<h2>Edit Teacher</h2>
    <form name="student" action="" method="post" enctype="multipart/form-data" onsubmit="return validateFormm();" >
	<table>
	</table>
	
<table border=0 cellspacing=0 cellpadding=2PX>

<tr>
<td>TEACHER_ID:</td>
<td><input type="text" name="tid" value="<?php echo $fetch['teacher_id'];?>">
</tr>

<tr>
<td>TEACHER_NAME:</td>
<td><input type="text" name="tname" onkeypress="return inputLimiter(event,'NameCharacters')" value="<?php echo $fetch['teacher_name'];?>">
</tr>
<td>username:</td>
<td><input type="text" name="uname" value="<?php echo $fetch['username']?>"></td>
</tr>
<tr>
<td>password:</td>
<td><input type="password" name="pswd" onblur="return abcde();" value="<?php echo $fetch['password'];?>">
</tr>
<tr>
<td>contact_no</td>
<td><input type="text" name="cno" value="<?php echo $fetch['contact_no'];?>" maxlength="10" onKeyPress="return isNumber(event);"></td>
</tr>

<tr>
<td>email_id</td>
<td><input type="text" name="emailid" value="<?php echo $fetch['email_id'];?>"></td>
</tr>
<tr>
<td>Status:</td>
<td><input type="text" name="status" READONLY id="status" VALUE="teacher"></td>
</tr>
<tr>
<td>
<input type="Submit" name="submit" value="submit">
</td>
</tr>
</center>
</table>
</form><br/><br/>
</body>
</html>
<?php
include_once("footer1.php");
?>
