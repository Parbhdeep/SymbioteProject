<?php 
include_once("db.php");
function sub()
{
$sel="select * from subject";
$exe=mysql_query($sel);
while($fetch=mysql_fetch_array($exe))
{
?>
<option value="<?php echo $fetch['subject_id'];?>">
<?php echo $fetch['subject_name'];?>
</option>
<?php
}
}
?>
