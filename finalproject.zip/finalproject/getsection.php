<?php
include_once("db.php");
$class_id=$_GET['class_id'];
//echo $class_id;
function section($cl)
{
$sel="select * from section where class_id='$cl'";
$exe=mysql_query($sel);
while($fetch=mysql_fetch_array($exe))
{?>

<option value="<?php echo $fetch['section_id'];?>"><?php echo $fetch['section_name'];?></option>

<?php

}
}
?>
<select>
<option value="">***select section***</option>
<?php
section($class_id);
?>
</select>
