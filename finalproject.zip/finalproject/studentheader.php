<?php
error_reporting(E_ALL^(E_NOTICE|E_WARNING));

?>
<link href="style.css" rel="stylesheet" type="text/css">

<table border="0" width="100%" height="10%" cellspacing="0" cellpadding="10" background="image/blackbar.jpg">
<tr>
<td>
</td>
</tr>
<tr>
<td class="style1">Android Academic Assistant Application

<img border="0" src="image/edu5.jpg" width="250" height="70" align="right"></td>
</td>
</tr>
</table>
<body >


<div id="container">
<ul id="header">
<li>
	<a href="student_navigation.php"><h3 style="color:white">Home </h3></a></li>
	<li>
	<a href="viewscore.php"><h3 style="color:white">View Marks</h3></a></li>
	<li>
	<a href="Online_exam/index.php"><h3 style="color:white">Online Exam</H3></a></li>
			<li>
		<a href="stupswd.php"><h3 style="color:white">Change Password</H3></a></li>
	
		<li>
		<a href="logout.php"><h3 style="color:white">Logout</H3></a></li>
		</ul>
		</div>
		</body>

