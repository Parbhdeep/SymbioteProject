<?php
ob_start();
include_once("db.php");
$classid=$_GET['classid'];
//echo $classid;
$sectionid=$_GET['sectionid'];
//$status=$_GET['status'];
//$status=0;
$subid=$_GET['subid'];
$month=$_GET['month'];
$present=explode(",",$_GET['present']);


//$timestamp = strtotime($string);
$date = date("Y-m-d");
//$month=$_GET['month'];
$select33="Select stu_id,class_id,section_id,stu_name from student_id where class_id='$classid' and section_id='$sectionid'"; 
$exe33=mysql_query($select33);	//$data[]=$row;
	//$i_query="insert into attandance set stu_id='".$row[0]."' ,stu_name='".$row[1]."',date='$date',status='$status'";
          //  $i_result = mysql_query ($i_query);
		  /*echo  $rows=mysql_num_rows($exe33);

        for ($i=0; $i<$rows; $i++) {


            $stu_info = "student_".$i;
            list($stu_id,,,$name,,,,,,,,) = $$emp_info;    
            
            
$i_query="insert into attandance set stu_id='$stu_id' ,stu_name='$name',date='$date',status='$status'";
            $i_result = mysql_query ($i_query);
}*/
$exe33=mysql_query($select33);
$i=0;
while($row=mysql_fetch_array($exe33)){
	$data[]=$row;
	$i_query="insert into attendence set stu_id='".$row[0]."' ,stu_name='".$row[3]."',class_id='".$row[1]."',section_id='".$row[2]."',subject_id='$subid',date='$date',status='".$present[$i]."'";
         $i_result = mysql_query ($i_query);
		$i++;
}

//echo "Sucessfully enter !";
//echo "<pre>";print_r($data);
?>