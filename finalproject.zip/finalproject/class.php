<?php
include_once("session.php");
include_once("db.php");
include_once("getclass.php");
include_once("getteacher.php");
include_once("schoolheader.php");
?>
<html>
<head>
	<script>
function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="getsection.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}
</script>
<script>
function validateFormm()
{

var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class name must be filled out");
  document.student.cid.focus();
 return false;
  }
var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section name must be filled out");
  document.student.sid.focus();
 return false;
  }
var x=document.forms["student"]["tname"].value;
if (x==null || x=="")
  {
  alert("Teacher name must be filled out");
  document.student.tname.focus();
 return false;
  }
}

</script>
</head>
  <body bgcolor="#c0cec2"> 
<center>
<title>A4 project</title>
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>

<div id="form3">
	<h2>Allot Teacher</h2>
    <form name="student" method="post" enctype="multipart/form-data" onsubmit="return validateFormm();" >
	<table>
	</table>
	
<table border=0 cellspacing=0 cellpadding=2PX>
<tr>
<td width="40%">ClassName:</td>
<td width=60%><select name="cid" id="classs" onchange="return getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php sctn(); ?>
</select></td>
</tr>
<tr>
<td width="40%">sectionName:</td>
<td width="60%"><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php   ?>
</select></td>
</tr>
<tr>
<td width="40%">TeacherName:</td>
<td width="60%"><select name="tname" id="tname">
<OPTION VALUE="">---select teacher---</OPTION>
<?php tchr(); ?>
</select></td>
</tr>
<tr><td><input type="submit" name="submit" value="submit"></td></tr>
</table>
</form>
</center>
</html>

<?php
include_once("db.php");
if(isset($_POST['submit']))
{
$select="select * from teacher_allocation where class_id='$_POST[cid]' && teacher_id='$_POST[tname]' && section_id='$_POST[sid]'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert(" already exist")';
print'</script>';


}
else
{
$sett="insert into teacher_allocation set class_id='$_POST[cid]',section_id='$_POST[sid]' ,teacher_id='$_POST[tname]'";
mysql_query($sett);
}
}
?>



<center>
<?php	
ob_start();
include_once("db.php");
//include_once("session.php");
//include_once("admin_navigation.php");


error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM teacher_allocation";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);

?>
<div id="table">
<table border="" width="70%">
<tr>
	<th>CLASS ID</th>
	<th>SECTION ID</th>
	<th>TEACHER NAME</th>
	
	
</tr>
<?php
//number of results per page
$display=2;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM teacher_allocation $limitQ";
$result11=mysql_query($query11);



while($fetch=mysql_fetch_object($result11))
{
$abc="select * from class where class_id='$fetch->class_id'";
$def=mysql_query($abc);
$ab=mysql_fetch_array($def);

$abcd="select * from section where section_id='$fetch->section_id'";
$defg=mysql_query($abcd);
$abb=mysql_fetch_array($defg);

$abcde="select * from teachers where teacher_id='$fetch->teacher_id'";
$defgh=mysql_query($abcde);
$abbc=mysql_fetch_array($defgh);

?>
<tr><td><?php print $ab['class_name'];?></td>
	<td><?php print $abb['section_name'];?></td>
	<td><?php print $abbc['teacher_name'];?></td>
	
	<td><a href= "classedit.php?teacher_id=<?php echo "$fetch->teacher_id"?>&class_id=<?php echo "$fetch->class_id"?>&section_id=<?php echo "$fetch->section_id"?>">Edit  </a></td>
    <td><a href= "classdelete.php?teacher_id=<?php echo "$fetch->teacher_id"?>&class_id=<?php echo "$fetch->class_id"?>&section_id=<?php echo "$fetch->section_id"?>">Delete  </a></td>
	
</tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=class.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=class.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}else{
$nextPage=$currentPage+1;
print "<a href=class.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=class.php?page=$lastPage>Last</a>";
}
?>
</center>
</div>
</body>
</html>
<?php
include_once("footer1.php");
?>


