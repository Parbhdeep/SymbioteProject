<?php
include_once("session.php");
ob_start();
include_once("db.php");

$delquery="delete from test where test_id='$_GET[test_id]'";
$exe1= mysql_query($delquery);

header("location:inserttest.php?msg=deleted$test_id='$_GET[test_id]'");	//for redirecting page to new page after login success

?>