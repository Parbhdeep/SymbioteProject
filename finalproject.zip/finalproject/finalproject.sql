-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 10, 2014 at 11:57 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `finalproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(30) NOT NULL,
  `admin_password` varchar(30) NOT NULL,
  `admin_fname` varchar(30) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `contact_no` bigint(11) NOT NULL,
  `image` varchar(60) NOT NULL,
  `status` varchar(30) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_username`, `admin_password`, `admin_fname`, `email_id`, `contact_no`, `image`, `status`, `date_time`) VALUES
(2, 'admin', 'admin1', 'Pritpal', 'dhillon@gmail.com', 9876789876, '', 'ADMIN', '2014-11-30 03:07:36'),
(5, 'adminn', 'adminn', 'jagmail', 'sidhu@gmail.com', 9876567898, '', 'ADMIN', '2014-11-30 03:14:13'),
(7, 'gurpinder', 'chahal', 'palwinder', 'chahal@gmail.com', 9876567898, '', 'ADMIN', '2014-11-22 11:57:45'),
(11, 'parbhdeep dhillon', 'dhillon', 'pritpal', 'dhillon@gmail.com', 9876787678, '', 'ADMIN', '2014-11-30 06:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE IF NOT EXISTS `attendence` (
  `stu_id` int(11) NOT NULL,
  `stu_name` varchar(20) NOT NULL,
  `class_id` varchar(20) NOT NULL,
  `section_id` varchar(20) NOT NULL,
  `subject_id` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`stu_id`, `stu_name`, `class_id`, `section_id`, `subject_id`, `date`, `status`) VALUES
(5, 'pamal', '1', '1', 'eng-501', '2014-10-31', 'p'),
(5, 'pamal', '1', '1', 'eng-501', '2014-10-31', 'p'),
(5, 'pamal', '1', '1', 'eng-501', '2014-10-31', 'p'),
(5, 'pamal', '1', '1', '', '2014-11-03', 'p'),
(6, 'parbh', '1', '1', '', '2014-11-03', 'p'),
(1, '1234', '3', '5', '', '2014-11-04', 'p'),
(3, 'pamal', '1', '1', '', '2014-11-22', 'p'),
(45, 'drthdtyn', '2', '4', '', '2014-12-09', 'p');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `class_name` varchar(30) DEFAULT NULL,
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_name`, `class_id`) VALUES
('Nursery', 1),
('KG', 2),
('1st', 3),
('2nd', 4);

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE IF NOT EXISTS `contactus` (
  `name` varchar(20) NOT NULL,
  `email_id` varchar(20) NOT NULL,
  `message` varchar(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`name`, `email_id`, `message`, `date`) VALUES
('prabh', 'dhillon@gmail.com', 'uywr', '2014-10-31'),
('prabh', 'dhillon@gmail.com', 'Update !!', '2014-10-31'),
('jassi', 'dhillon@gmail.com', 'new user', '2014-11-01'),
('amrit', 'dhillon@gmail.com', 'again new user', '2014-11-01'),
('amrit', 'dhillon@gmail.com', 'again new user', '2014-11-01'),
('amrit', 'dhillon@gmail.com', 'again new user', '2014-11-01'),
('amrit', 'dhillon@gmail.com', 'again new user', '2014-11-01'),
('amrit', 'dhillon@gmail.com', 'again new user', '2014-11-01'),
('amrit', 'dhillon@gmail.com', 'again new user', '2014-11-01'),
('amrit', 'dhillon@gmail.com', 'again new user', '2014-11-01'),
('amrit', 'dhillon@gmail.com', 'again new user', '2014-11-01'),
('pamal', 'abc@gmail.com', 'gud one !!', '2014-11-02'),
('', '', '', '2014-11-04'),
('', '', '', '2014-11-04'),
('', '', '', '2014-11-16'),
('', '', '', '2014-11-16'),
('', '', '', '2014-11-16'),
('', '', '', '2014-11-16'),
('', '', '', '2014-11-16'),
('', '', '', '2014-11-16'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-17'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-20'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-22'),
('', '', '', '2014-11-29'),
('', '', '', '2014-11-29'),
('', '', '', '2014-11-29'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-11-30'),
('', '', '', '2014-12-04'),
('', '', '', '2014-12-05'),
('', '', '', '2014-12-07'),
('', '', '', '2014-12-08'),
('', '', '', '2014-12-08'),
('', '', '', '2014-12-10'),
('', '', '', '2014-12-10'),
('', '', '', '2014-12-10'),
('', '', '', '2014-12-10');

-- --------------------------------------------------------

--
-- Table structure for table `parent`
--

CREATE TABLE IF NOT EXISTS `parent` (
  `parent_id` int(11) NOT NULL,
  `father_name` varchar(30) NOT NULL,
  `mother_name` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent`
--

INSERT INTO `parent` (`parent_id`, `father_name`, `mother_name`, `username`, `password`, `status`) VALUES
(5, 'jagmail singh', 'gurmeet kaur', '', 'sidhu', 'student'),
(1, 'jagmail singh', 'gurmeet kaur', 'pamalsidhu@gmail.com', 'sidhu', 'student'),
(1, 'jagmail singh', 'gurmeet kaur', 'pamalsidhu@gmail.com', 'sidhu', 'student'),
(1, 'jagmail singh', 'gurmeet kaur', 'pamalsidhu@gmail.com', 'sidhu', 'student'),
(1, 'jagmail singh', 'gurmeet kaur', 'pamalsidhu@gmail.com', 'sidhu', 'student'),
(6, 'pritpal singh', 'surinder kaur', 'dhillon@gmail.com', 'dhillon', 'student'),
(78, 'trty', 'ytftyf', 'yyfrggyjurfe', 'ytfuhbrr', 'student'),
(3, 'kihxis', 'shci', 'rfbgtn', 'fb b', 'student'),
(3, 'kihxis', 'shci', 'rfbgtn', 'fb b', 'student'),
(3, 'kihxis', 'shci', 'rfbgtn', 'fb b', 'student'),
(3, 'kihxis', 'shci', 'rfbgtn', 'fb b', 'student'),
(3, 't', 'nhn', 'rfbgtn', 'hnyjf', 'student'),
(3, 't', 'nhn', 'rfbgtn', 'hnyjf', 'student'),
(45, 'umym', 'eumri,r', 'fh,fmk,', 'jy,fuk', 'student'),
(65, 'gbbb', 'htyh', 'hgj', 'hvmb,', 'student'),
(56, 'd ,fbnk', 'kgfbnlk', 'jnvk ', 'jfbnk', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE IF NOT EXISTS `school` (
  `school_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_name` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `principal` varchar(30) NOT NULL,
  `mobile_no` bigint(11) NOT NULL,
  `landline_no` bigint(11) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`school_id`, `school_name`, `username`, `password`, `address`, `city`, `principal`, `mobile_no`, `landline_no`, `email_id`, `status`) VALUES
(9, 'school', 'school', 'sch', 'khanna', 'khanna', 'principal', 9876787656, 9878767877, 'school@gmail.com', 'school'),
(11, 'A', 'nursery', '34', 'tp', 'tp', 'jk', 24, 4, 'student', 'gill'),
(12, 'B', 'Ist', '484', 'jk', 'jk', 'jk', 24, 4, 'student', 'dhanjal'),
(13, 'C', '2nd', '449', 'parbh', 'parbh', 'jk', 12, 4, 'student', 'parbh');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE IF NOT EXISTS `section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` varchar(30) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `strength` int(11) NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `section_name`, `class_id`, `strength`) VALUES
(2, 'B', 1, 0),
(3, 'C', 1, 60),
(4, 'A', 2, 2),
(5, 'A', 3, 0),
(6, 'B', 3, 0),
(8, 'A', 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `studentscore`
--

CREATE TABLE IF NOT EXISTS `studentscore` (
  `stu_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `test_id` int(11) NOT NULL,
  `subject_id` varchar(20) NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentscore`
--

INSERT INTO `studentscore` (`stu_id`, `username`, `test_id`, `subject_id`, `score`) VALUES
(5, '', 2, 'eng-501', 12),
(6, 'dhillon@gmail.com', 2, 'eng-501', 12),
(1, 'pamalsidhu@gmail.com', 4, 'eng-501', 9),
(34, 'tp', 2, 'eng-501', 45),
(34, 'tp', 2, 'eng-501', 45);

-- --------------------------------------------------------

--
-- Table structure for table `student_id`
--

CREATE TABLE IF NOT EXISTS `student_id` (
  `section_id` varchar(20) NOT NULL,
  `class_id` varchar(20) NOT NULL,
  `stu_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `DOB` varchar(20) NOT NULL,
  `age` int(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `stu_name` varchar(30) DEFAULT NULL,
  `gender` varchar(20) NOT NULL,
  `f_name` varchar(30) DEFAULT NULL,
  `m_name` varchar(30) DEFAULT NULL,
  `p_mobile` bigint(11) DEFAULT NULL,
  `image` text NOT NULL,
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_id`
--

INSERT INTO `student_id` (`section_id`, `class_id`, `stu_id`, `username`, `password`, `address`, `DOB`, `age`, `status`, `stu_name`, `gender`, `f_name`, `m_name`, `p_mobile`, `image`) VALUES
('3', '1', 3, 'kiran', '9878789878', 'g', '12-7-2010', 4, 'student', 'pamal', 'F', 'kihxis', 'shci', 9876556, ''),
('8', '4', 449, 'parbh', 'parbh', 'jk', '07/27/2010', 4, 'student', 'parbh', 'F', 'fp', 'mp', 9878987878, 'parbh.jpg'),
('6', '3', 484, 'jk', 'jk', 'jk', '0000-00-00', 4, 'student', 'dhanjal', 'female', 'fjk', 'fjk', 9878987878, 'jk.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `subject_id` varchar(20) NOT NULL,
  `subject_name` varchar(30) NOT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_name`) VALUES
('eng-501', 'english'),
('pbi-501 ', 'pbi');

-- --------------------------------------------------------

--
-- Table structure for table `subject_allocation`
--

CREATE TABLE IF NOT EXISTS `subject_allocation` (
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` varchar(20) NOT NULL,
  `sa_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`sa_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `subject_allocation`
--

INSERT INTO `subject_allocation` (`class_id`, `section_id`, `subject_id`, `sa_id`) VALUES
(3, 6, 'eng-501', 2),
(2, 4, 'pbi-501 ', 7);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
  `teacher_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `contact_no` bigint(11) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_name`, `username`, `password`, `contact_no`, `email_id`, `status`) VALUES
(1, 'parbh', 'parbh', 'parbh', 9878767876, 'dhillon@gmail.com', 'teacher'),
(2, 'pamal', 'pamal', 'sidhu', 8765464356, 'sidhu@gmail.com', 'teacher');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_allocation`
--

CREATE TABLE IF NOT EXISTS `teacher_allocation` (
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_allocation`
--

INSERT INTO `teacher_allocation` (`class_id`, `section_id`, `teacher_name`) VALUES
(1, 2, '1'),
(2, 4, '2'),
(1, 2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_name` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` varchar(30) NOT NULL,
  `marks` int(11) NOT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`test_id`, `test_name`, `date`, `class_id`, `section_id`, `subject_id`, `marks`) VALUES
(3, 'mst2', '2014-10-31', 1, 1, 'eng-501', 100),
(4, 'eng', '2014-12-10', 3, 6, 'eng-501', 50),
(5, 'eval', '0000-00-00', 3, 5, 'btcs-501', 100),
(6, 'test', '2014-10-31', 2, 4, 'eng-501', 23),
(7, 'girtbjpot', '2014-11-20', 1, 0, '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
