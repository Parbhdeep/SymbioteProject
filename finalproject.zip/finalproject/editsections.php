<?php
include_once("session.php");
ob_start();
include_once("db.php");
include_once("getclass.php");
include_once("schoolheader.php");
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
$sett="select * from section where section_id='$_GET[section_id]'";
$exe=mysql_query($sett);
$fetch=mysql_fetch_array($exe);
$abcde=$_GET[class_id];
if(isset($_POST['submit']))
{

$section=$_POST['section'];
$class=$_POST['cname'];
$select="select * from section where section_name='$section' AND class_id='$class' ";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Section already exist")';
print'</script>';

}
else
{

$up="update section set section_name='$_POST[section]',class_id='$_POST[cname]'
where section_id='$_GET[section_id]' and class_id='$_GET[class_id]'";


$exe1= mysql_query($up);
header("location:sections.php");
}
}
?>
<?php
function se($cll)
{
$sell="select * from class";
$exee=mysql_query($sell);
while($fetchh=mysql_fetch_array($exee))
{
?>
<option value='<?php echo $fetchh['class_id'];?>'<?php if($fetchh['class_id']==$cll){ echo "selected='selected'";}?> ><?php echo $fetchh['class_name'];?></option>

<?php

}
}
?>
<html>
<body bgcolor="#c0cec2">
<script>
function validateFormm()
{

var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class name must be filled out");
  document.student.cid.focus();
 return false;
  }

var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section name must be filled out");
  document.student.sid.focus();
 return false;
  }  }
</script>
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>
		<center>
		<h2>Edit Section</h2>
		<form name="student" method="post" onsubmit="return validateFormm();">
		<table>
		<tr>
		<td>
<select name="cname" id=cid >
<OPTION VALUE="">---select class---</OPTION>
<?php se($abcde); ?>
</select></td>
<td>
			section name:<input type="text" name="section" id="sid" value="<?php echo $fetch['section_name'] ?>"></br></td></tr>
			<tr><td><input type="submit" name="submit" value="submit"></td></tr>
			<table>
			</form>
			</center>
		</body>
</html>
<?php
include_once("footer2.php");
?>