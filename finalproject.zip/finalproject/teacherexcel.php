<?php
include_once("excelheader.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>Upload page</title>

<style type="text/css">

body {

    background:  #c0cec2;

    font: normal 14px/30px Helvetica, Arial, sans-serif;

    color: #2b2b2b;

}

a {

    color:black;

    font-size:14px;

    font-weight:bold;

    text-decoration:none;

}

a:hover {

    color:white;

}

 

h1 {

    font: bold 14px Helvetica, Arial, sans-serif;

    color: #CC0033;

}

h2 {

    font: bold 14px Helvetica, Arial, sans-serif;

    color: #898989;

}
#container {

    background:grey;

    margin: 100px auto;

    width:950px;
	height:300px;
	color:black;

}
#form           {padding: 20px 150px;}
#form input     {margin-bottom: 20px;}
</style>

</head>

<body>

<div id="container">

<div id="form">


<?php
include_once("db.php");
if (isset($_POST['submitexcel'])) {

    if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
	//move_uploaded_file($_FILES["filename"]["tmp_name"], "excel/lata/".$_FILES["filename"]["name"]);
	  echo "<h1>" . "File ". $_FILES['filename']['name'] ." uploaded successfully." . "</h1>";
        echo "<h2>Displaying contents:</h2>";
        readfile($_FILES['filename']['tmp_name']);
     }

   

 

    //Import uploaded file to Database

    $handle = fopen($_FILES['filename']['tmp_name'], "r");

$i=0;
    while (($data = fgetcsv($handle, 1000, ",")) != FALSE) {
$i++;

    if($i==1) continue;

        echo $import="INSERT into teachers(teacher_name,username,password,contact_no,email_id,status) values('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')";

        mysql_query($import);

    }

    fclose($handle);

    print "Import done";

    //view upload form

}else {


 
    print "Upload new csv by browsing to file and clicking on Upload<br />";
	
    print "<form enctype='multipart/form-data' action='teacherexcel.php' method='post' style='margin:auto'>";
    
    print "File name to import:";

    print "<input size='50' type='file' name='filename'><br />\n";

    print "<input type='submit' name='submitexcel' value='Upload'></form>";

}
?>
</div>
<img src='eteacher.png'>
</div>
</body>

</html>

