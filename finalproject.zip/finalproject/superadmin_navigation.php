<?php
ob_start();
include_once("db.php");
include_once("header1.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
var image1 = new Image()
image1.src = "image/school_building.jpg"
var image2 = new Image()
image2.src = "image/image4.jpg"
var image3 = new Image()
image3.src = "image/image5.jpg"
var image4 = new Image()
image4.src = "image/image1.jpg"
var image5 = new Image()
image5.src = "image/edu3.jpg"
var image6 = new Image()
image6.src = "image/image2.jpg"
</script>
</head>
<body>

<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
<LI>
		<a href="admin.php">Create Admin</a></li>
		<LI>
		<a href="school.php">Create School</a></li>
	<LI>
		
		
		</ul>
		</div>
		</div>
		</div>
		
</div>
<p><img src="images/school_building.jpg" width="550" height="300" name="slide" /></p>
<script type="text/javascript">
        var step=1;
        function slideit()
        {
            document.images.slide.src = eval("image"+step+".src");
            if(step<6)
                step++;
            else
                step=1;
            setTimeout("slideit()",3500);
        }
        slideit();
</script>
</p>
<?php
include_once("footer1.php");
?>
</body>		
</html>
