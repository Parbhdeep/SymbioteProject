<?php
include_once("db.php");
include_once("func.php");
include_once("schoolheader.php");
?>
<html>
<head>
	<script>
	function validateFormm()
{
var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class id   must be filled out");
  document.student.cid.focus();
 return false;
  }
  var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section id   must be filled out");
  document.student.cid.focus();
 return false;
  }
  var x=document.forms["student"]["stuid"].value;
if (x==null || x=="")
  {
  alert("student  id must be filled out");
   document.student.sname.focus();
 return false;
  }
var x=document.forms["student"]["sname"].value;
if (x==null || x=="")
  {
  alert("student  name must be filled out");
   document.student.sname.focus();
 return false;
  }
  
  var x=document.forms["student"]["fathername"].value;
if (x==null || x=="")
  {
  alert("father name must be filled out");
   document.student.sname.focus();
 return false;
  }
  var x=document.forms["student"]["mothername"].value;
if (x==null || x=="")
  {
  alert("mothername  name must be filled out");
   document.student.sname.focus();
 return false;
  }
  var x=document.forms["student"]["dob"].value;
if (x==null || x=="")
  {
  alert("date of birth must be filled out");
   document.student.dob.focus();
 return false;
  }
  var x=document.forms["student"]["pass"].value;
if (x==null || x=="")
  {
  alert("password must be filled out");
   document.student.pass.focus();
 return false;
  }
 
   var x=document.forms["student"]["age"].value;
if (x==null || x=="")
  {
  alert("age must be filled out");
   document.student.age.focus();
 return false;
  }

  var x=document.forms["student"]["mno"].value;
if (x==null || x=="")
  {
  alert("contact no must be filled out");
   document.student.mno.focus();
 return false;
  }
    if ((x.length <10) || (x.length > 10))
{
alert("invalid mobile no");
document.teachers.mob.focus();
return false;
}
}
function abc()
{
var currentd=new Date();
//alert(currentd);
var dobb=document.student.dob.value;
var d=new Date(dobb);
var y1=currentd.getFullYear();
var y2=d.getFullYear();
var y3=y1-y2;
document.student.age.value=y3;

}
function abcd()
{
var a=document.student.eid.value;
if(a=="")
{
alert("username must be filled");
document.student.eid.focus();
}
}
function abcde()
{
	var b=document.student.pass.value;
	var c=b.length;
	if(c<3||c>11)
	{
		alert("password length must be between 3 and 11");
	}
}
function abcdef()
{
	if((!document.student.gender[0].checked)&&(!document.student.gender[1].checked))
	{
		alert("specify gender");
	}
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function inputLimiter(e,allow) {
    var AllowableCharacters = '';

    if (allow == 'Letters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';}
    if (allow == 'Numbers'){AllowableCharacters='1234567890';}
    if (allow == 'NameCharacters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-.\'';}
    if (allow == 'NameCharactersAndNumbers'){AllowableCharacters='1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-\'';}
	
    var k = document.all?parseInt(e.keyCode): parseInt(e.which);
    if (k!=13 && k!=8 && k!=0){
        if ((e.ctrlKey==false) && (e.altKey==false)) {
        return (AllowableCharacters.indexOf(String.fromCharCode(k))!=-1);
        } else {
        return true;
        }
    } else {
        return true;
    }
} 

function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="funcs.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}
</script>
</head>
<body  bgcolor="#c0cec2">
<link href="style.css" rel="stylesheet" type="text/css">
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
<LI>
		<a href="studentexcel.php">Import using excel</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>
<center>
<h2>Add student</h2>
<title>A4 project</title>
<div id="form3">
	
    <form name="student" action="" method="post" enctype="multipart/form-data" onSubmit="return validateFormm();" >
	<table>
	</table>
	
<table border=0 cellspacing=0 cellpadding=2PX>
<tr>
<td>ClassName:</td>
<td><select name="cid" id="classs" onchange="return getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php func1(); ?>
</select></td>
</tr>

<tr>
<td>sectionName:</td>
<td><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php   ?>
</select></td>
</tr>
<tr>
<td>STUDENT_ID:</td>
<td><input type="text" name="stuid" placeholder="student Id" />
</tr>

<tr>
<td>STUDENT_NAME:</td>
<td><input type="text" name="sname" placeholder="student name" onkeypress="return inputLimiter(event,'NameCharacters')" value=""/>
</tr>

<tr>
<td>Gender:</td>
<td><input type="radio" name="gender" value="M"> MALE
<input type="radio" name="gender" value="F">FEMALE</td>
</tr>
<tr>
<td>FATHER_NAME:</td>
<td><input type="text" name="fathername"  onkeypress="return inputLimiter(event,'NameCharacters')" placeholder="Father Name" onfocus="return abcdef();" >
</tr>
<tr>
<td>MOTHER_NAME:</td>
<td><input type="text" name="mothername"  onkeypress="return inputLimiter(event,'NameCharacters')" placeholder="Mother Name" />
</tr>
<tr>
<td>Parent_Mobilno:</td>
<td><input type="text" name="mno" placeholder="mobile number" maxlength=10 onKeyPress="return isNumber(event);" ></td>
</tr>
<tr>
<td>username:</td>
<td><input type="text" name="eid" placeholder="username" onblur="return abcd();"></td>
</tr>
<tr>
<td>password:</td>
<td><input type="password" name="pass" placeholder="password" onblur="return abcde();">
</tr>
<tr>
<td>Address:</td>
<td><input type="text" name="addr" placeholder="address" ></td>
</tr>

<tr>
<td>Date Of Birth</td>
<td><input type="date" name="dob" id="dob" placeholder="DOB" />mm/dd/yyyy</td>
</tr>
<tr>
<td>Age</td>
<td><input type="text" name="age" id="age" placeholder="age" onfocus="return abc();"></td>
</tr>
<tr>
<td>IMAGE:</td>
<td><input type="file" name="file" id="file"></td>
</tr>
<tr>
<td>Status:</td>
<td><input type="text" name="status" READONLY id="status" VALUE="student"></td>
</tr>
<tr>
<td>
<input type="Submit" name="submit" value="submit">
</td>
</tr>
</center>
</table>
</form><br/><br/>

<?php
	
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM student_id";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);
?>
<table border>
<tr>
     <th>ClassID</th>
	 <th>SectionId</th>
	<th>studentName</th>
	
	<th>MobileNo</th>
	<th>username</th>
	<th>Address</th>
	<th>DOB</th>
	<th>AGE</th>
	<th>GENDER</th>
</tr>

<?php
//number of results per page
$display=2;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM student_id $limitQ";
$result11=mysql_query($query11);


while($fetch=mysql_fetch_object($result11))
{
$abc="select * from class where class_id='$fetch->class_id'";
$def=mysql_query($abc);
$ab=mysql_fetch_array($def);

$abcd="select * from section where section_id='$fetch->section_id'";
$defg=mysql_query($abcd);
$abb=mysql_fetch_array($defg);
?>
<tr><td><?php print $ab['class_name'];?></td>
<td><?php print $abb['section_name'];?></td>
	<td><?php print "$fetch->stu_name"?></td>
	<td><?php print "$fetch->p_mobile"?></td>
	<td><?php print "$fetch->username"?></td>
	<td><?php print "$fetch->address"?></td>
	<td><?php print "$fetch->DOB"?></td>
	<td><?php print "$fetch->age"?></td>
	<td><?php print "$fetch->gender"?></td>
	<td><img src="upload/<?php print "$fetch->image" ?> " alt ="<?php print "$fetch->image;" ?>" title="<?php echo "$fetch->image;" ?>" width="50" height="50" /></td>
 <td><a href= "edit.php?stu_id=<?php echo "$fetch->stu_id"?>&class_id=<?php echo "$fetch->class_id"?>&section_id=<?php echo "$fetch->section_id"?>">Edit  </a></td>
    <td><a href= "delete.php?stu_id=<?php echo "$fetch->stu_id"?>&class_id=<?php echo "$fetch->class_id"?>&section_id=<?php echo "$fetch->section_id"?>">Delete  </a></td>
	
 </tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=section.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=section.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}
else{
$nextPage=$currentPage+1;
print "<a href=section.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=section.php?page=$lastPage>Last</a>";
}
?>
</div>
</div>
<?php
include_once("db.php");
if(isset($_POST['submit']))
{
	
$uname=$_POST['eid'];
$filename=$_FILES['file']['name'];
move_uploaded_file($_FILES["file"]["tmp_name"], "UPLOAD/".$_FILES["file"]["name"]);
$select1="select * from section where class_id='$_POST[cid]' and section_id='$_POST[sid]'";
$exe1=mysql_query($select1);
$fetchs=mysql_fetch_array($exe1);
$strength=$fetchs['strength'];
$strength=$strength+1;
$sett="insert into student_id set class_id='$_POST[cid]',section_id='$_POST[sid]' ,stu_id='$_POST[stuid]',username='$_POST[eid]',password='$_POST[pass]',
address='$_POST[addr]',DOB='$_POST[dob]',age='$_POST[age]',status='$_POST[status]',stu_name='$_POST[sname]',
gender='$_POST[gender]',f_name='$_POST[fathername]',m_name='$_POST[mothername]',p_mobile='$_POST[mno]',image='$filename'";
mysql_query($sett);

 $in="insert into parent set parent_id='$_POST[stuid]',username='$_POST[eid]',password='$_POST[pass]',
father_name='$_POST[fathername]',mother_name='$_POST[mothername]',status='$_POST[status]'";

mysql_query($in);


$updatequery="update section set strength='$strength' where class_id='$_POST[cid]' and section_id='$_POST[sid]'";
mysql_query($updatequery);
}
?>
</body>
</html>
<?php
include_once("footer1.php");
?>
