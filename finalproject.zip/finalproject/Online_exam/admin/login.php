<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Administrative Area Online Quiz </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#c0cec2">
<?php
include("teacherheader.php");
extract($_POST);
if(isset($submit))
{
	include("../database.php");
	$rs=mysql_query("select * from mst_admin where loginid='$loginid' and pass='$pass'",$cn) or die(mysql_error());
	if(mysql_num_rows($rs)<1)
	{
		echo "<BR><BR><BR><BR><div class=head1> Invalid User Name or Password<div>";
		exit;
		
	}
	$_SESSION[alogin]="true";
	
}
else if(!isset($_SESSION[alogin]))
{
	echo "<BR><BR><BR><BR>Your are not logged in<br> Please <a href=index.php>Login</a>";
		exit;
}
?>

<h2><center>Welcome to Administrative Area</center> </h2>
<p align="center" ><a href="subadd.php">Add Subject</a></p>
<p align="center" ><a href="testadd.php">Add Test</a></p>
<p align="center" ><a href="questionadd.php">Add Question </a></p>
<p align="center" ><a href="addstudent.php">Add student</a></p>
<p align="center">&nbsp;</p>
</body>
</html>
