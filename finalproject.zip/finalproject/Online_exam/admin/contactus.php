<?php
include_once("teacherheader.php");
include_once("session.php");
?>
<script>

function validate()
{
var x=document.contact.name.value;
if(x==""||x==null)
{
alert("fill ur name");
document.contact.name.focus();
 return false;
 }
 var x=document.contact.email.value;
if(x==""||x==null)
{
alert("fill ur emailid");
document.contact.email.focus();
 return false;
}
}


</script>
<link href="style.css" rel="stylesheet" type="text/css">
<title>A4 Project</title>
<table border="0" width="100%" height="10%" cellspacing="0" cellpadding="10" background="" >
<tr><th class="style2"><center>Follow US</center></th>
<th class="style2">Contact US</th>
<th class="style2">Enquiry</th>
</tr>
<tr>
<td><img border="0" src="image/fb.jpg" width="100" height="70">
<img border="0" src="image/twitter.jpg" width="100" height="60"></td>
<td>
EUREKA ELECTROSOFT SOLUTIONS Pvt.Ltd<br/>
Plot No.: E-55, F1st floor<br/>
Phase-8 Industrial Area<br/> 
Near C-DAC Mohali (Punjab)<br/>
Ph.: 0172-4638606, 5091855<br/>
 M: 9815216606.
</td>
<td>

<form name="contact" method="post" onsubmit="return validate();">  
 Name*<br/><input name="name" type="text"   onfocus="if(this.value=='Your Name')this.value=''" onblur="if(this.value=='')this.value='Your Name'"/><BR/><BR/>
   Email_Id*<br/><input name="email" type="text"   onfocus="if(this.value=='Your E-mail Address')this.value=''" onblur="if(this.value=='')this.value='Your E-mail Address'"/><BR/><BR/>
    <textarea name="txt_msg"  rows="" cols="" onfocus="if(this.value=='Put your message here')this.value=''" onblur="if(this.value=='')this.value='Put your message here'">Put your message here</textarea><br/><br/>
   <INPUT TYPE="SUBMIT" NAME="submit" value="submit"/></form>

</td>
</tr>
</table>
<?php
ob_start();
include_once("db.php");
if(isset($_POST['submit']))

{
$date = date("Y-m-d h:i:s");
$insertquery="insert contactus set name='$_POST[name]',email_id='$_POST[email]',message='$_POST[txt_msg]',date='$date'";
$exe1= mysql_query($insertquery);
}
