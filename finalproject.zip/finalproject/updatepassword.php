<?php
if(isset($_POST['submit']))
{
echo $_POST['newpswd'];
}
?>
<!DOCTYPE html>
<html>
<head>

</head>
<body>
<script>
function myFunction() {
var z = document.createElement("FORM");
    z.setAttribute("id", "myForm");
	   z.setAttribute("method", "post");
    document.body.appendChild(z);
    var y = document.createElement("input");
    y.setAttribute("type", "text");
     y.setAttribute("name", "newpswd");
	// document.fname.newpswd.visiblility=true;
    document.getElementById("myForm").appendChild(y);
var x = document.createElement("input");
    x.setAttribute("type", "submit");
     x.setAttribute("name", "submit");
	      x.setAttribute("value", "submit");
	// document.fname.newpswd.visiblility=true;
    document.getElementById("myForm").appendChild(x);
}
</script>
<form class="ab">
username:<input type="text" name="txt"/>
password:<input type="password" name="pawd"/>
<button onclick="return myFunction();">Try it</button>

<p id="demo"></p>

</body>
</html>
