<?php
include_once("session.php");
include_once("schoolheader.php");
include_once("db.php");
include_once("getclass.php");
include_once("getsubjects.php");
?>
<?php
if(isset($_POST['submit']))
{
$date=date(y);
$select="select * from subject_allocation where class_id='$_POST[cid]' && subject_id='$_POST[subid]' && section_id='$_POST[sid]'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("already exist")';
print'</script>';
}
else
{
$insertquery="insert into subject_allocation set class_id='$_POST[cid]',section_id='$_POST[sid]',subject_id='$_POST[subid]'";
$exe1= mysql_query($insertquery);
header("location:sub_allot.php?msg=ok");	//for redirecting page to new page after login success
}
}
?>
<html>
<head>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style2.css" rel="stylesheet" type="text/css" />
<script>
function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="getsection.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}

</script>

<script>

function validateFormm()



{

	var classid=document.forms["sub"]["cid"].value;
	var secid=document.forms["sub"]["sid"].value;
	var subid=document.forms["sub"]["subid"].value;
	
if (classid==null || classid=="")
  {
  alert("class id   must be filled out");
  document.sub.cid.focus();
 return false;
  }

if (secid==null || secid=="")
  {
  alert("section  must be filled out");
   document.sub.sname.focus();
 return false;
  }
  if(subid==null || subid=="")
{
alert("subject must be filled out");
document.sub.subid.focus();
return false;
}
		
	}



</script>
</head>
<body bgcolor="#c0cec2">
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>
		<center>
		<h2>Allot Subject</h2>
<form name="sub"action="" method="post" enctype="multipart/form-data" onsubmit="return validateFormm();">
<table>
</table>
<table border=0 cellspacing=0 cellpadding=2px>
<tr>
<td width="40%">ClassName:</td>
<td width="60%"><select name="cid" id="classs" onchange="getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php sctn(); ?>
</select></td>
</tr>
<tr>
<td width="40%">sectionName:</td>
<td width="60%"><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php  ?>
</select></td>
</tr>
<tr>
<td width="40%">SubjectName:</td>
<td width="60%"><select name="subid" id="siddd">
<OPTION VALUE="">---select subject---</OPTION>
<?php sub(); ?>
</select></td>
</tr>
<tr>
<td>
<input type="submit" name="submit" value="submit"/>
</td>

<td>
<input type="reset" name="submitt" value="Clear">
</td>
</tr>
</table>
</center>
</form><br/><br/><br/>

<?php
	
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM subject_allocation";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);
?>
<center>
<div id="tablee">
<table border="" width="70%">
<tr>
    
	<th>classId</th>
	<th>sectionId</th>
	<th>subjectId</th>
</tr>

<?php
//number of results per page
$display=2;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM subject_allocation $limitQ";
$result11=mysql_query($query11);


while($fetch=mysql_fetch_object($result11))
{
$abc="select * from class where class_id='$fetch->class_id'";
$def=mysql_query($abc);
$ab=mysql_fetch_array($def);

$abcd="select * from section where section_id='$fetch->section_id'";
$defg=mysql_query($abcd);
$abb=mysql_fetch_array($defg);
?>
<tr><td><?php print $ab['class_name'];?></td>
<td><?php print $abb['section_name'];?></td>
<td><?php print "$fetch->subject_id"?></td>
	<td><a href= "editsubs.php?sa_id=<?php echo $fetch->sa_id;?>&class_id=<?php echo $fetch->class_id;?>&section_id=<?php echo $fetch->section_id;?>&subject_id=<?php echo $fetch->subject_id;?>">Edit  </a></td>
    <td><a href= "dltesubs.php?sa_id=<?php echo "$fetch->sa_id"?>">Delete  </a></td>
 </tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=sub_allot.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=sub_allot.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}else{
$nextPage=$currentPage+1;
print "<a href=sub_allot.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=sub_allot.php?page=$lastPage>Last</a>";
}
?>
</center>
 </div>
  </body>
</html>
<?php
include_once("footer1.php");
?>

