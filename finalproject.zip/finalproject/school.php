<?php
include_once("session.php");
include_once("adminheader.php");

?>
<script>
function validateFormm()
{
var x=document.forms["student"]["sname"].value;
if (x==null || x=="")
  {
  alert("schoolname must be filled out");
  document.student.sname.focus();
 return false;
  }
  var x=document.forms["student"]["addr"].value;
if (x==null || x=="")
  {
  alert("address must be filled out");
  document.student.addr.focus();
 return false;
  }
  var x=document.forms["student"]["uname"].value;
if (x==null || x=="")
  {
  alert("username must be filled out");
  document.student.uname.focus();
 return false;
  }
  var x=document.forms["student"]["pswd"].value;
if (x==null || x=="")
  {
  alert("password must be filled out");
  document.student.pswd.focus();
 return false;
  }
    var x=document.forms["student"]["mno"].value;
if (x==null || x=="")
  {
  alert("mobile number must be filled out");
   document.student.mno.focus();
 return false;
  }
  if ((x.length <10) || (x.length > 10))
{
alert("invalid mobile no");
document.student.mno.focus();
return false;
}
   var x=document.forms["student"]["lno"].value;
if (x==null || x=="")
  {
  alert("landline number must be filled out");
   document.student.lno.focus();
 return false;
  }
  if ((x.length <11) || (x.length > 11))
{
alert("invalid landline no");
document.student.lno.focus();
return false;
}
  var x=document.forms["student"]["emailid"].value;
if (x==null || x=="")
  {
  alert("Email id must be filled out");
   document.student.emailid.focus();
 return false;
  }

  var x=document.forms["student"]["principal"].value;
if (x==null || x=="")
  {
  alert("Principal must be filled out");
   document.student.principal.focus();
 return false;
  }

  var x=document.forms["student"]["city"].value;
if (x==null || x=="")
  {
  alert("City must be filled out");
   document.student.city.focus();
 return false;
  }
 }
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function abcde()
{
	var b=document.student.pswd.value;
	var c=b.length;
	if(c<3||c>11)
	{
		alert("password length must be between 3 and 11");
	}
}
function inputLimiter(e,allow) {
    var AllowableCharacters = '';

    if (allow == 'Letters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';}
    if (allow == 'Numbers'){AllowableCharacters='1234567890';}
    if (allow == 'NameCharacters'){AllowableCharacters=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-.\'';}
    if (allow == 'NameCharactersAndNumbers'){AllowableCharacters='1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-\'';}
	
    var k = document.all?parseInt(e.keyCode): parseInt(e.which);
    if (k!=13 && k!=8 && k!=0){
        if ((e.ctrlKey==false) && (e.altKey==false)) {
        return (AllowableCharacters.indexOf(String.fromCharCode(k))!=-1);
        } else {
        return true;
        }
    } else {
        return true;
    }
} 

</script>

<html>
<body bgcolor="#c0cec2">
<title>A4 Project</title>
	  <link rel="stylesheet" href="style.css">
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
<LI>
		<a href="admin.php">Create Admin</a></li>
		<LI>
		<a href="schoolexcel.php">Import Using Excel</a></li>
	<LI>
		<a href="teacher.php">Create Teacher</a></li>
		</ul>
		</div>
		</div>
		</div>
		
</div>
<div id="form3">
	<center>
	<h2>Add School</h2>
    <form name="student" action="" method="post" enctype="multipart/form-data"  onsubmit="return validateFormm();" >
	<table>
	</table>
<table border=0 cellspacing=0 cellpadding=2PX>

<tr>
<td>SCHOOL_NAME:</td>
<td><input type="text" name="sname" placeholder="school name" onkeypress="return inputLimiter(event,'NameCharacters')" value=""/>
</tr>

<tr>
<td>ADDRESS:</td>
<td><input type="text" name="addr" placeholder="address"/>
</tr>
<td>username:</td>
<td><input type="text" name="uname" placeholder="username"></td>
</tr>
<tr>
<td>password:</td>
<td><input type="password" name="pswd" placeholder="password" onblur="return abcde();">
</tr>
<tr>
<td>mobile_no</td>
<td><input type="text" name="mno" placeholder="mobile no" maxlength="10" onKeyPress="return isNumber(event);"></td>
</tr>
<tr>
<td>landline_no</td>
<td><input type="text" name="lno" placeholder="landline no" maxlength="11" onKeyPress="return isNumber(event);"></td>
</tr>

<tr>
<td>email_id</td>
<td><input type="text" name="emailid" placeholder="Email id"></td>
</tr>
<tr>
	<tr>
<td>principal</td>
<td><input type="text" name="principal"  onkeypress="return inputLimiter(event,'NameCharacters')" placeholder="principal"></td>
</tr>
<tr>
<td>city</td>
<td><input type="text" name="city"  onkeypress="return inputLimiter(event,'NameCharacters')" placeholder="city"></td>
</tr>


<td>Status:</td>
<td><input type="text" name="status" READONLY id="status" VALUE="school"></td>
</tr>
<tr>
<td>
<input type="Submit" name="submit" value="submit">
</td>
</tr>
</center>
</table>
</form><br/><br/>

<?php
	include_once("db.php");
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM school";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);
?>
<table border>
<tr>
     <th>SCHOOL_NAME</th>
	 <th>USERNAME</th>
	<th>PRINCIPAL</th>
	
	<th>ADDRESS</th>
	<th>CITY</th>

</tr>

<?php
//number of results per page
$display=4;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM school $limitQ";
$result11=mysql_query($query11);


while($fetch=mysql_fetch_object($result11))
{?>
<tr><td><?php print "$fetch->school_name"?></td>
<td><?php print "$fetch->username"?></td>
	<td><?php print "$fetch->principal"?></td>
	<td><?php print "$fetch->address"?></td>
	<td><?php print "$fetch->city"?></td>
 <td><a href= "schooledit.php?school_id=<?php echo "$fetch->school_id"?>">Edit  </a></td>
    <td><a href= "schooldelete.php?school_id=<?php echo "$fetch->school_id"?>">Delete  </a></td
	
 </tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=teacher.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=teacher.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}
else{
$nextPage=$currentPage+1;
print "<a href=teacher.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=teacher.php?page=$lastPage>Last</a>";
}
?>
</div>
</div>

</body>
</html>
<?php
include_once("db.php");
if(isset($_POST['submit']))
{
$user=$_POST['uname'];
$email=$_POST['emailid'];
$select="select * from school where username='$user' or email_id='$email'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Username already exist")';
print'</script>';

}
else
{
 $sett="insert into school set school_name='$_POST[sname]',address='$_POST[addr]',username='$_POST[uname]',password='$_POST[pswd]',status='$_POST[status]',city='$_POST[city]',
principal='$_POST[principal]',mobile_no='$_POST[mno]',landline_no='$_POST[lno]',email_id='$_POST[emailid]'";

mysql_query($sett);

//mysql_query($updatequery);
}
}
?>
<?php
include_once("footer1.php");
?>