<?php
ob_start();
include_once("db.php");
$classid=$_GET['classid'];
$sectionid=$_GET['sectionid'];
$subid=$_GET['subid'];
 //echo $classid;
function testlist($ciid,$secid,$sub)
{
	$selectt="select * from test where class_id='$ciid' and section_id='$secid' and subject_id='$sub'";
	$exe=mysql_query($selectt);
	while($fetch = mysql_fetch_array($exe)) 
	
	{
	
	
 ?>
  
<option value="<?php  echo $fetch['test_id'];?>" > <?php   echo $fetch['test_name'];?> </option>

<?php
	}}
 ?>
 
<select name="test" id="test" >
<option value="">*** Select test***</option> 
<?php 
 testlist($classid,$sectionid,$subid);
?>
</select>
 
 