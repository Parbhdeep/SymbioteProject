<?php
include_once("db.php");
include_once("func.php");
?>
<html>
<head>
	<script>
function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="getsection.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}
</script>
</head>
<html>
	<body bgcolor="sky blue">
		<center>
		<form name="subject" method="post">
			    <form name="student" action="" method="post" enctype="multipart/form-data" >
	
<table border=0 cellspacing=0 cellpadding=2PX>
<tr>
<td>ClassName:</td>
<td><select name="cid" id="classs" onchange="return getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php func1(); ?>
</select></td>
</tr>

<tr>
<td>sectionName:</td>
<td><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php   ?>
</select></td>
</tr>
<tr>
<td>subject:</td>
<td><select name="sname" id="sname">
<OPTION VALUE="">---select subject---</OPTION>
<?php sub(); ?>
</select></td>
</tr>
Test name:<input type="text" name="tname" ></br>
Marks:<input type="text" name="marks" ></br>
</table>

			<input type="submit" name="submit" value="submit">
			<input type="reset" name="clear" value="clear">
			</form>
			</center>
		</body>
</html>
<?php
include_once("db.php");
if(isset($_POST['submit']))
{
$sett="insert into subject set subject_name='$_POST[sname]',subject_id='$_POST[sid]'";
mysql_query($sett);

}
?>
