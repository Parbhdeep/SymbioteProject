<?php
ob_start();
include_once("db.php");
include_once("getsubjects.php");
error_reporting(E_ALL^(E_NOTICE));
$classid=$_GET['classid'];
$sectionid=$_GET['sectionid'];

$select133="Select * from student_id where	class_id='$classid' and section_id='$sectionid'"; 

 $exe111=mysql_query($select133);
 $rows=mysql_num_rows($exe111);
 $select12="Select * from student_id where	class_id='$classid' and section_id='$sectionid'"; 

 $exe12=mysql_query($select12);
 $fetch=mysql_fetch_array($exe12);

 ?>
 <head><link href="style2.css" rel="stylesheet" type="text/css" /></head>
 <CENTER><table border>
<tr><td>studentId</td><td>NAME</td><td><input type="button" name="btn" id="check" value="Present/Absent" onclick="choseall();"/></td></tr>
<?php
 
while( $result111 = mysql_fetch_array($exe111))
{
?>
	
	<tr><td><?php echo $result111['stu_id'];?></td> <td><?php echo $result111['stu_name'];?></td><td><INPUT TYPE="checkbox" name="present[]" id="checkk"   />present</TD></tr>
	
<?php } ?></CENTER>
 
<hr/><B>SEARCH RESULT</B>
</hr>
 <hr/> <BR><BR>
subName:
<select name="sub" id="sub">
<OPTION VALUE="">---select subject---</OPTION>
<?php sub() ; ?>
</select><BR/></BR>


</hr>
 <tr><td><input type="button" name="add" value="add" onclick="return insert();"/></td></tr>
 <table >
 </form>
</body>
</html>