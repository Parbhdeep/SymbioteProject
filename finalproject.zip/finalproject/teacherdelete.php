<?php
include_once("session.php");
include_once("db.php");
$del="delete from teachers where teacher_id='$_GET[teacher_id]'";
mysql_query($del);
header("location:teacher.php?msg=deleted$teacher_id='$_GET[teacher_id]'");
?>
