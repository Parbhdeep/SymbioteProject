<?php 
include_once("db.php");
function tchr()
{
$sel="select * from teachers";
$exe=mysql_query($sel);
while($fetch=mysql_fetch_array($exe))
{
?>
<option value="<?php echo $fetch['teacher_id'];?>">
<?php echo $fetch['teacher_name'];?>
</option>
<?php
}
}
?>
