<?php
include_once("session.php");
ob_start();
include_once("db.php");
include_once("getclass.php");
include_once("getsubjects.php");
include_once("teacherheader.php");
//include_once("funcsubject.php");


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>A4 Project</title>
<link href="style.css" rel="stylesheet" type="text/css" />


<script>

function getSection()
{
	//alert("gftshy");
var xmlhttp;
if(window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();
}
else
{
xmlhttp=new ActiveXObject(Microsoft.XMLHTTP);
}
var url="funcs.php";

var class_id=document.getElementById("classs").value;
var url=url+"?class_id="+class_id;
//alert(url);
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
{
document.getElementById("ssid").innerHTML=xmlhttp.responseText;
}
}

}

</SCRIPT>

<SCRIPT>
function getTest()
{
	var xmlhttp;
	
	if(window.XMLHttpRequest)
	{//code for IE7+,firefox,chorme,opera,safari
	 xmlhttp = new XMLHttpRequest();
	}
	else
	{//code for IE6,IE5
	xmlhttp = new ActiveXobject("Microsoft.XMLHTTP");
	}
	
var url = "testsubfunc.php";
	
var classid = document.getElementById('classs').value;	
var sectionid = document.getElementById('ssid').value;	
var subid = document.getElementById('sub').value;
url = url +"?classid="+classid+"&sectionid="+sectionid+"&subid="+subid;

//alert(url);

xmlhttp.open("GET", url, true);
xmlhttp.send();

	xmlhttp.onreadystatechange=function()
	{
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
			  {
				  document.getElementById("test").innerHTML=xmlhttp.responseText;
				   
			  }
		 }
}

</SCRIPT>
<SCRIPT>
function gett()
{
	var xmlhttp;
	
	if(window.XMLHttpRequest)
	{//code for IE7+,firefox,chorme,opera,safari
	 xmlhttp = new XMLHttpRequest();
	}
	else
	{//code for IE6,IE5
	xmlhttp = new ActiveXobject("Microsoft.XMLHTTP");
	}
	
var url = "insertMark.php";
	
var testid=document.getElementById("test").value
var classid = document.getElementById('classs').value;	
var sectionid = document.getElementById('ssid').value;	
//alert(sectionid);
url = url +"?classid="+classid+"&sectionid="+sectionid+"&testid="+testid;
//alert(url);
xmlhttp.open("GET", url, true);
xmlhttp.send();

	xmlhttp.onreadystatechange=function()
	{
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
			  {
			document.getElementById("testt").innerHTML=xmlhttp.responseText;
				   
			  }
		 }
}
</script>
<script>
function insert(){
var xmlhttp;

	if(window.XMLHttpRequest)
	{//code for IE7+,firefox,chorme,opera,safari
	 xmlhttp = new XMLHttpRequest();
	}
	else
	{//code for IE6,IE
	xmlhttp = new ActiveXobject("Microsoft.XMLHTTP");
	}
	
var classid=document.getElementById("classs").value;
//alert(classid);
var sectionid=document.getElementById("ssid").value;
var testtid=document.getElementById("test").value;
//var subid=document.getElementById("sub").value;
//alert(subid);
var subid = document.getElementById('sub').value;
var values = new Array();
var score=document.querySelectorAll("input[name='score[]']");
var length=score.length;
for(var i=0;i<length;i++)
{
values[i] = score[i].value;
}
//alert(values);
//var month=document.getElementById("month").value;
//var month=document.getElementById("month").value;
var url="insertMarks.php";
url=url+"?classid="+classid+"&sectionid="+sectionid+"&testtid="+testtid+"&score="+values+"&subid="+subid;
//alert(url);
xmlhttp.open("GET", url, true);
xmlhttp.send();

 
return false;		
}

</script>
<script>
function validateFormm()
{
var x=document.forms["student"]["cid"].value;
if (x==null || x=="")
  {
  alert("class id   must be filled out");
  document.student.cid.focus();
 return false;
  }

  
  var x=document.forms["student"]["sid"].value;
if (x==null || x=="")
  {
  alert("section id   must be filled out");
  document.student.cid.focus();
 return false;
  }

  
  
  
 
  
  }

 



</script>
</head>

<body bgcolor="#c0cec2">
<div id="form">
<center>
<h2>Insert Marks</h2>
  <form name="student" action="" method="post" enctype="multipart/form-data" onSubmit="return validateFormm();">

<?php

if(isset($_POST['submit']))
 {
$msg=$_GET['msg'];
if($msg=="notok")
{
	?><tr><td> <?php echo "Already Exists"; ?></td></tr>
<?php 
} 

}?>
 
ClassName:
<select name="cid" id="classs" onChange="getSection();">
<OPTION VALUE="">---select class---</OPTION>
<?php sctn(); ?>
</select><BR/><BR/>


sectionName:
<td><select name="sid" id="ssid">
<OPTION VALUE="">---select section---</OPTION>
<?php  ?>
</select><BR/><BR/>


subjectName:
<td><select name="sub" id="sub"  onchange="getTest();">
<OPTION VALUE="">---select subject---</OPTION>
<?php sub(); ?>
</select><BR/><BR/>


TestName:
<select name="test" id="test" onChange="gett();">
<OPTION VALUE="">---select Test---</OPTION>
<?php  ?>
</select><BR/><BR/>



<div id="testt">
</div>

</form>
    </DIV>
	</center>
   
</body>
</html>
<?php
include_once("footer1.php");
?>
