<?php
include_once("db.php");
//include_once("funcScore");
//include_once("funcsubject");
$stuid=$_GET['stuid'];
error_reporting(E_ALL^(E_WARNING|E_NOTICE));

$selectQuery="select * from studentScore where stu_id='$stuid'";
$exe=mysql_query($selectQuery);

?>
 <head><link href="style2.css" rel="stylesheet" type="text/css" /></head>
<table  cellspacing="10px" cellpadding="0px" align="left">
<tr><th>StudentId</th><th>Subjectid</th><th >score</th></tr>
<?php
 
while( $result111 = mysql_fetch_array($exe))
{
?>
	
	<tr><td><?php echo $result111['stu_id'];?></td> <td><?php echo $result111['subject_id'];?></td> <td><?php echo $result111['score'];?></TD></tr>
	
<?php } ?>