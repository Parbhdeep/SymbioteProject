<?php
include_once("session.php");
include_once("db.php");

$delquery="delete from teacher_allocation where class_id='$_GET[class_id]' and section_id='$_GET[section_id]' ";
$exe1= mysql_query($delquery);

header("location:class.php?msg=deleted$teacher_name='$_GET[teacher_name]'");	//for redirecting page to new page after login success

?>