<?php
include_once("session.php");
include_once("schoolheader.php");
?>
<html>
<body bgcolor="#c0cec2">
<script>
function validateFormm()
{
var x=document.forms["clsses"]["class"].value;
if (x==null || x=="")
  {
  alert("class name must be filled out");
  document.clsses.class.focus();
 return false;
  }
  }
</script>
<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>

<title>A4 project</title>
		<center>
		<h2>Enter class </h2>
		<form name="clsses" method="post" onsubmit="return validateFormm();">
		<table>
		<tr>
			<td>Class Name:</td>
			<td><input type="text" name="class" id="class" placeholder="class" ></br></td></tr>
			<tr><td><input type="submit" name="submit" value="submit"></td></tr>
			</form>
			</table>
			</center>
<?php
include_once("db.php");
if(isset($_POST['submit']))
{

$class=$_POST['class'];
$select="select * from class where class_name='$class'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Class already exist")';
print'</script>';

}
else
{

$sett="insert into class set class_name='$_POST[class]'";
mysql_query($sett);

}
}
?>

<?php	
ob_start();
include_once("db.php");
//include_once("session.php");
//include_once("admin_navigation.php");


error_reporting(E_ALL^(E_WARNING|E_NOTICE));
//get the number of rows
$query="SELECT * FROM class";
$result1=mysql_query($query);
//number of records found
$num_record=mysql_num_rows($result1);

?>
<div id="table">
<center>
<table border="" width="70%" >
<tr>
	<th>class id</th>
	<th>Class name</th>
	
	
</tr>
<?php
//number of results per page
$display=2;
if(isset($_GET['page'])){
$currentPage=$_GET['page'];
}else{
$currentPage=1;
}
//last page

$lastPage=ceil($num_record/$display);
//limit in the query thing
$limitQ='LIMIT '.(($currentPage-1)*$display).','.$display;
//normal query and print results
$query11="SELECT * FROM class $limitQ";
$result11=mysql_query($query11);


while($fetch=mysql_fetch_object($result11))
{?>
<tr><td><?php print "$fetch->class_id"?></td>
	<td><?php print "$fetch->class_name"?></td>
	
	<td><a href= "editclass.php?class_id=<?php print $fetch->class_id;?>">Edit  </a></td>
    <td><a href= "dlteclass.php?class_id=<?php print $fetch->class_id;?>">Delete  </a></td>
	
</tr>
 <?php } ?>

</table>
<?php
if($currentPage==1){
print "prev";
}
else
{
	print "<a href=clsses.php?page=1>First Page</a>";
	echo $previousPage=$currentPage-1;
	print "<a href=clsses.php?page=$previousPage>Previous</a>";
}
print "{page:-$currentPage of $lastPage)";
//for next pages links
if($currentPage==$lastPage){
print "next";
}else{
$nextPage=$currentPage+1;
print "<a href=clsses.php?page=$nextPage>Next</a>&nbsp;";
print "<a href=clsses.php?page=$lastPage>Last</a>";
}
?>
</center>
</div>
</body>
</html>
<?php
include_once("footer1.php");
?>

