<?php
include_once("session.php");
include_once("db.php");
include_once("schoolheader.php");
error_reporting(E_ALL^(E_WARNING|E_NOTICE));
$select121="Select * from class where class_id='$_GET[class_id]'"; 
$exe121=mysql_query($select121);
$fetch11=mysql_fetch_array($exe121); 

if(isset($_POST['submit']))
{
$class=$_POST['class'];
$select="select * from class where class_name='$class'";
$exe=mysql_query($select);
$rows=mysql_num_rows($exe);
if($rows > 0)
{
print'<script type="text/javascript">';
print'alert("Class already exist")';
print'</script>';

}
else
{
$updatequery="update class set class_name='$_POST[class]'
where class_id='$_GET[class_id]'";
$exe1= mysql_query($updatequery);

header("location:clsses.php?msg=updated$class_id='$_GET[class_id]'");	//for redirecting page to new page after login success

}
}
?>

<script>
function validateFormm()
{
var x=document.forms["clsses"]["class"].value;
if (x==null || x=="")
  {
  alert("class name must be filled out");
  document.clsses.class.focus();
 return false;
  }
  }
</script>
<html>
<body bgcolor="#c0cec2">

<div id="leftmenu">
<div id="leftmenu_top">
<div id="leftmenu_main">
<ul>
	<LI>
		<a href="section.php">Create student</a></li>
		<li>
		<a href="clsses.php">Create class</a></li>
		<li>
		<a href="sections.php">Create section</a></li>
		<li>
		<a href="subject.php">Create subject</a></li>
		<li>
		<a href="class.php">Allot teacher</a></li>
		<li>
		<a href="sub_allot.php">Allot Subject</a></li>
		</ul>
		</div>
		</div>
		</div>
		<center>
		<title>A4 Project</title>
		<h2>Edit class </h2>
		<form name="clsses" method="post" onsubmit="return validateFormm();">
			<table>
			<tr>
			<td>Class Name:</td>
			<td><input type="text" name="class" id="class"  value="<?php echo $fetch11['class_name'] ?>" ></br></td>
			<tr>
			<tr><td><input type="submit" name="submit" value="submit"></td></tr>
			</form>
			</center>
			</table>
		</body>
</html>
<?php
include_once("footer2.php");
?>