<?php
include_once("session.php");
include_once("db.php");
$del="delete from school where school_id='$_GET[school_id]'";
mysql_query($del);
header("location:school.php?msg=deleted$school_id='$_GET[school_id]'");
?>
